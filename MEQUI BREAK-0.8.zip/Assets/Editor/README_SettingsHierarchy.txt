SETTINGS HIERARCHY

The Settings screen is baked into Assets/Scenes/Settings/Settings.unity by an Editor-only installer.
Runtime scripts only reference the serialized objects already present in the scene; they do not create the Settings UI.

If the scene is opened in Unity and the Settings hierarchy is missing, the Editor installer rebuilds and saves it once.
After that, the full hierarchy remains serialized in the .unity scene file.
