Áudio da versão 0.4.1

Os arquivos originais enviados pelo usuário são usados diretamente via Resources:
- ui_click.mp3 <- Clique2.mp3
- ui_confirm.mp3 <- Clique do Botoes.mp3
- pb_reward.mp3 <- Moedas subindo.mp3
- minigame_complete.mp3 <- Task Completada.mp3
- energy_drag_tick.mp3 <- ArrastabotoesEnergyStation.mp3
- login_music.mp3 <- Mcdonald's commercial music.mp3

Mapeamento:
- ui_click: cliques normais de UI.
- ui_confirm: confirmações importantes já existentes no projeto.
- pb_reward: início da sequência de recompensa de PB.
- minigame_complete: conclusão do Energy Station/minigame.
- energy_drag_tick: início do arraste no Energy Station.
- login_music: toque musical curto no Boot/primeiro acesso; NÃO fica em loop.

O AudioManager agora carrega esses clips automaticamente de Resources e cria AudioSources
caso as referências da cena estejam ausentes. Isso evita silêncio causado por Inspector
references quebradas após migração.

Não foi criado um loop musical contínuo porque o arquivo enviado é um jingle comercial,
não uma trilha ambiente feita para repetição.
