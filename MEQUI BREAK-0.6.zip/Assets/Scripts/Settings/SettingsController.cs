using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Conecta a tela de Configurações aos serviços persistentes e permite editar
/// Loja/Turno sem invalidar o primeiro login.
/// </summary>
public sealed class SettingsController : MonoBehaviour
{
    [Header("Preferências")]
    [SerializeField] private Toggle musicToggle;
    [SerializeField] private Toggle sfxToggle;
    [SerializeField] private Toggle notificationsToggle;
    [SerializeField] private Toggle endOfShiftReminderToggle;

    [Header("Dados do funcionário")]
    [SerializeField] private Button workSettingsButton;
    [SerializeField] private GameObject workSettingsPanel;
    [SerializeField] private RectTransform settingsContent;
    [SerializeField] private TMP_InputField storeInput;
    [SerializeField] private TMP_Text shiftValueText;
    [SerializeField] private TMP_Text feedbackText;

    private void Start()
    {
        SettingsManager settings = SettingsManager.Instance;
        if (settings != null)
        {
            musicToggle?.SetIsOnWithoutNotify(settings.MusicEnabled);
            sfxToggle?.SetIsOnWithoutNotify(settings.SFXEnabled);
            notificationsToggle?.SetIsOnWithoutNotify(settings.NotificationsEnabled);
            endOfShiftReminderToggle?.SetIsOnWithoutNotify(settings.EndOfShiftReminderEnabled);
        }

        PlayerManager player = PlayerManager.Instance;
        if (player != null)
        {
            storeInput?.SetTextWithoutNotify(player.StoreId);
            if (shiftValueText != null)
                shiftValueText.text = player.Shift;
        }

        SetWorkPanelOpen(false);
        BindListeners();
        RefreshReminderInteractable();
        SetFeedback(string.Empty);
    }

    private void BindListeners()
    {
        if (musicToggle != null) musicToggle.onValueChanged.AddListener(SetMusic);
        if (sfxToggle != null) sfxToggle.onValueChanged.AddListener(SetSFX);
        if (notificationsToggle != null) notificationsToggle.onValueChanged.AddListener(SetNotifications);
        if (endOfShiftReminderToggle != null) endOfShiftReminderToggle.onValueChanged.AddListener(SetEndOfShiftReminder);
        if (workSettingsButton != null) workSettingsButton.onClick.AddListener(ToggleWorkSettingsPanel);
        if (storeInput != null) storeInput.onEndEdit.AddListener(SetStore);
    }

    private void UnbindListeners()
    {
        if (musicToggle != null) musicToggle.onValueChanged.RemoveListener(SetMusic);
        if (sfxToggle != null) sfxToggle.onValueChanged.RemoveListener(SetSFX);
        if (notificationsToggle != null) notificationsToggle.onValueChanged.RemoveListener(SetNotifications);
        if (endOfShiftReminderToggle != null) endOfShiftReminderToggle.onValueChanged.RemoveListener(SetEndOfShiftReminder);
        if (workSettingsButton != null) workSettingsButton.onClick.RemoveListener(ToggleWorkSettingsPanel);
        if (storeInput != null) storeInput.onEndEdit.RemoveListener(SetStore);
    }

    public void ToggleWorkSettingsPanel()
    {
        bool shouldOpen = workSettingsPanel != null && !workSettingsPanel.activeSelf;
        SetWorkPanelOpen(shouldOpen);
        AudioManager.Instance?.PlayClick();
    }

    private void SetWorkPanelOpen(bool isOpen)
    {
        if (workSettingsPanel != null)
            workSettingsPanel.SetActive(isOpen);

        if (settingsContent != null)
        {
            Canvas.ForceUpdateCanvases();
            LayoutRebuilder.ForceRebuildLayoutImmediate(settingsContent);
        }
    }

    public void SetMusic(bool enabled) => SettingsManager.Instance?.SetMusicEnabled(enabled);

    public void SetSFX(bool enabled)
    {
        SettingsManager.Instance?.SetSFXEnabled(enabled);

        // O mesmo toque que liga os efeitos pode chegar ao feedback visual
        // antes ou depois do callback do Toggle, dependendo da ordem dos
        // componentes. Disparar aqui garante confirmação audível já no
        // primeiro toque; o cooldown do AudioManager evita duplicação.
        if (enabled)
            AudioManager.Instance?.PlayClick();
    }

    public void SetNotifications(bool enabled)
    {
        SettingsManager.Instance?.SetNotificationsEnabled(enabled);
        if (!enabled)
            endOfShiftReminderToggle?.SetIsOnWithoutNotify(false);
        RefreshReminderInteractable();
    }

    public void SetEndOfShiftReminder(bool enabled) =>
        SettingsManager.Instance?.SetEndOfShiftReminderEnabled(enabled);

    public void SetStore(string value) => UpdateWorkData(value, PlayerManager.Instance?.Shift);

    public void SelectMorning() => SelectShift("Manhã");
    public void SelectAfternoon() => SelectShift("Tarde");
    public void SelectNight() => SelectShift("Noite");

    private void SelectShift(string shift) => UpdateWorkData(PlayerManager.Instance?.StoreId, shift);

    private void UpdateWorkData(string store, string shift)
    {
        PlayerManager player = PlayerManager.Instance;
        if (player == null)
            return;

        if (player.TryUpdateWorkData(store, shift, out string error))
        {
            storeInput?.SetTextWithoutNotify(player.StoreId);
            if (shiftValueText != null)
                shiftValueText.text = player.Shift;
            SetFeedback("Dados atualizados.");
            AudioManager.Instance?.PlayConfirm();
        }
        else
        {
            storeInput?.SetTextWithoutNotify(player.StoreId);
            SetFeedback(error);
        }
    }

    private void RefreshReminderInteractable()
    {
        if (endOfShiftReminderToggle != null)
            endOfShiftReminderToggle.interactable = notificationsToggle == null || notificationsToggle.isOn;
    }

    private void SetFeedback(string message)
    {
        if (feedbackText != null)
            feedbackText.text = message;
    }

    // Compatibilidade temporária até a cena antiga ser migrada no Editor.
    public void SetMusicVolume(float value) => SetMusic(value > 0.001f);
    public void SetSFXVolume(float value) => SetSFX(value > 0.001f);
    public void SetVibration(bool enabled) => SettingsManager.Instance?.SetVibration(enabled);

    private void OnDestroy() => UnbindListeners();
}
