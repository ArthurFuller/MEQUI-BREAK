using DG.Tweening;
using TMPro;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public sealed class CustomizationController : MonoBehaviour
{
    [Header("Cena")]
    [SerializeField] private SceneLoader sceneLoader;
    [SerializeField] private string hubScene = "HUB";

    [Header("Pré-visualização")]
    [SerializeField] private AvatarView avatarPreview;

    [Header("Catálogo")]
    [Tooltip("Regras centrais de desbloqueio. Sem catálogo, todas as opções são consideradas gratuitas.")]
    [SerializeField] private AvatarCustomizationCatalog catalog;

    [Header("Controles")]
    [SerializeField] private Button hatButton;
    [SerializeField] private Button faceButton;
    [SerializeField] private Button colorButton;
    [SerializeField] private Button confirmButton;

    [Header("Indicador de aba")]
    [SerializeField] private bool animateTabIndicator = true;
    [SerializeField, Min(1f)] private float tabIndicatorHeight = 5f;
    [SerializeField, Range(0.3f, 1f)] private float tabIndicatorWidthMultiplier = 0.72f;
    [SerializeField, Min(0f)] private float tabIndicatorBottomOffset = 5f;
    [SerializeField, Min(0.05f)] private float tabIndicatorDuration = 0.22f;
    [SerializeField] private Ease tabIndicatorEase = Ease.OutCubic;

    [Header("Opções")]
    [SerializeField] private GameObject[] hatOptions;
    [SerializeField] private GameObject[] faceOptions;
    [SerializeField] private GameObject[] colorOptions;

    [Header("Feedback (opcional)")]
    [SerializeField] private TMP_Text feedbackLabel;

    [Header("Confirmação de compra (opcional)")]
    [Tooltip("Sem painel, a compra com Break Points é tentada imediatamente ao clicar.")]
    [SerializeField] private GameObject purchaseConfirmPanel;
    [SerializeField] private TMP_Text purchaseConfirmLabel;
    [SerializeField] private Button purchaseConfirmYesButton;
    [SerializeField] private Button purchaseConfirmNoButton;

    [Header("Animação em onda da grade")]
    [Tooltip("Reproduz uma onda de baixo para cima quando uma categoria fica visível.")]
    [SerializeField] private bool animateOptionWave = true;

    [Tooltip("Duração do movimento de entrada de cada opção.")]
    [SerializeField, Min(0.05f)] private float optionWaveDuration = 0.32f;

    [Tooltip("Intervalo entre opções da mesma linha.")]
    [SerializeField, Min(0f)] private float optionWaveItemDelay = 0.045f;

    [Tooltip("Intervalo adicional quando a onda avança para a próxima linha.")]
    [SerializeField, Min(0f)] private float optionWaveRowDelay = 0.08f;

    [Tooltip("Distância abaixo da posição final em que cada opção começa.")]
    [SerializeField, Min(0f)] private float optionWaveStartOffset = 80f;

    [Tooltip("Curva usada no movimento de entrada das opções.")]
    [SerializeField] private Ease optionWaveEase = Ease.OutCubic;

    [Header("Animação do painel de compra")]
    [Tooltip("Duração da entrada do painel de compra.")]
    [SerializeField, Min(0.05f)] private float purchasePanelEnterDuration = 0.25f;

    [Tooltip("Duração da saída do painel de compra.")]
    [SerializeField, Min(0.05f)] private float purchasePanelExitDuration = 0.2f;

    [Tooltip("Fator de escala inicial da entrada do painel.")]
    [SerializeField, Min(1f)] private float purchasePanelEnterScale = 1.1f;

    private readonly AvatarCustomizationData previewData = new AvatarCustomizationData();
    private AvatarCustomizationCategory selectedCategory = AvatarCustomizationCategory.Hat;
    private AvatarCustomizationItem pendingPurchaseItem;

    private AvatarOptionButton[] hatButtons;
    private AvatarOptionButton[] faceButtons;
    private AvatarOptionButton[] colorButtons;
    private OptionWaveTarget[] hatWaveTargets;
    private OptionWaveTarget[] faceWaveTargets;
    private OptionWaveTarget[] colorWaveTargets;

    [Header("Referências visuais pré-configuradas")]
    [SerializeField] private RectTransform tabIndicator;
    [SerializeField] private CanvasGroup feedbackCanvasGroup;
    [SerializeField] private RectTransform purchasePanelRect;
    [SerializeField] private CanvasGroup purchasePanelCanvasGroup;

    private RectTransform _purchasePanelRect;
    private CanvasGroup _purchasePanelCanvasGroup;
    private CanvasGroup _feedbackCanvasGroup;
    private Sequence _purchasePanelSequence;

    private Sequence _optionWaveSequence;
    private readonly List<OptionWaveTarget> _activeOptionWaveTargets = new List<OptionWaveTarget>();
    private readonly List<OptionWaveTarget> _optionWaveSortBuffer = new List<OptionWaveTarget>(12);

    private Sequence _feedbackSequence;

    private RectTransform _tabIndicator;
    private Sequence _tabIndicatorSequence;
    private bool _started;
    private bool _buttonsBound;

    private sealed class OptionWaveTarget
    {
        public RectTransform RectTransform;
        public CanvasGroup CanvasGroup;
        public Vector2 FinalPosition;
        public float X;
        public float Y;
    }

    private void Awake()
    {
        _tabIndicator = tabIndicator;
        _feedbackCanvasGroup = feedbackCanvasGroup;
        _purchasePanelRect = purchasePanelRect;
        _purchasePanelCanvasGroup = purchasePanelCanvasGroup;
    }

    private void Start()
    {
        _started = true;
        CopyFromSavedAvatar();
        ApplyPreview();
        CacheOptionButtons();
        CacheOptionWaveTargets();
        PrepareOptionsHiddenForInitialWave();
        BindButtons();
        RefreshVisibleOptions();
        RefreshLockVisuals();
        RefreshSelectionVisuals();
        CachePanelReferences();

        CreateTabIndicator();
        if (animateTabIndicator || animateOptionWave)
            Canvas.ForceUpdateCanvases();
        UpdateTabIndicator(animate: false);

        StartCoroutine(PlayInitialOptionWaveWhenReady());

        if (purchaseConfirmPanel != null)
            purchaseConfirmPanel.SetActive(false);

    }

    private void PrepareOptionsHiddenForInitialWave()
    {
        if (!animateOptionWave)
            return;

        SetWaveTargetsAlpha(hatWaveTargets, 0f);
        SetWaveTargetsAlpha(faceWaveTargets, 0f);
        SetWaveTargetsAlpha(colorWaveTargets, 0f);
    }

    private static void SetWaveTargetsAlpha(OptionWaveTarget[] targets, float alpha)
    {
        if (targets == null)
            return;

        for (int i = 0; i < targets.Length; i++)
        {
            if (targets[i]?.CanvasGroup != null)
                targets[i].CanvasGroup.alpha = alpha;
        }
    }

    private IEnumerator PlayInitialOptionWaveWhenReady()
    {
        while (SceneLoader.IsTransitionInProgress)
            yield return null;

        yield return null;
        PlayOptionWave();
    }

    private void OnDisable()
    {
        KillOptionWave(true);
        KillFeedbackTween();
        KillPurchasePanelTween();
        UnbindButtons();
    }

    private void OnEnable()
    {
        if (_started)
            BindButtons();
    }

    private void OnDestroy()
    {
        KillOptionWave(false);
        KillFeedbackTween();
        KillPurchasePanelTween();

        if (_tabIndicatorSequence != null && _tabIndicatorSequence.IsActive())
            _tabIndicatorSequence.Kill(false);

        UnbindButtons();
    }

    private void CachePanelReferences()
    {
        EnsurePurchasePanelReferences();
    }

    // Troca de categoria

    public void SelectHat()
    {
        SelectCategory(AvatarCustomizationCategory.Hat);
    }

    public void SelectFace()
    {
        SelectCategory(AvatarCustomizationCategory.Face);
    }

    public void SelectColor()
    {
        SelectCategory(AvatarCustomizationCategory.Color);
    }

    private void SelectCategory(AvatarCustomizationCategory category)
    {
        if (selectedCategory == category)
        {
            // A aba ativa também pode reiniciar a animação.
            PlayOptionWave();
            return;
        }

        selectedCategory = category;
        RefreshVisibleOptions();
        if (animateTabIndicator || animateOptionWave)
            Canvas.ForceUpdateCanvases();
        UpdateTabIndicator(animate: true);
        PlayOptionWave(forceLayout: false);
    }

    // Indicador de aba

    private void CreateTabIndicator()
    {
        if (animateTabIndicator && _tabIndicator == null)
            Debug.LogWarning("Indicador de aba não foi atribuído no Inspector.", this);
    }

    private void UpdateTabIndicator(bool animate)
    {
        if (!animateTabIndicator || _tabIndicator == null)
            return;

        Button targetButton = selectedCategory switch
        {
            AvatarCustomizationCategory.Hat => hatButton,
            AvatarCustomizationCategory.Face => faceButton,
            AvatarCustomizationCategory.Color => colorButton,
            _ => hatButton
        };

        if (targetButton == null || targetButton.transform is not RectTransform targetRect)
            return;

        RectTransform parent = _tabIndicator.parent as RectTransform;
        if (parent == null)
            return;

        Bounds bounds = RectTransformUtility.CalculateRelativeRectTransformBounds(parent, targetRect);

        Vector2 targetPosition = new Vector2(
            bounds.center.x,
            bounds.min.y - tabIndicatorBottomOffset);

        Vector2 targetSize = new Vector2(
            Mathf.Max(1f, bounds.size.x * tabIndicatorWidthMultiplier),
            tabIndicatorHeight);

        if (_tabIndicatorSequence != null && _tabIndicatorSequence.IsActive())
            _tabIndicatorSequence.Kill(false);

        _tabIndicatorSequence = null;

        if (!animate)
        {
            _tabIndicator.anchoredPosition = targetPosition;
            _tabIndicator.sizeDelta = targetSize;
            return;
        }

        _tabIndicatorSequence = DOTween.Sequence()
            .SetUpdate(UpdateType.Late)
            .Join(
                _tabIndicator
                    .DOAnchorPos(targetPosition, tabIndicatorDuration)
                    .SetEase(tabIndicatorEase)
                    .SetUpdate(UpdateType.Late))
            .Join(
                _tabIndicator
                    .DOSizeDelta(targetSize, tabIndicatorDuration)
                    .SetEase(tabIndicatorEase)
                    .SetUpdate(UpdateType.Late));
    }

    public void HandleOptionClicked(int optionIndex)
    {
        if (optionIndex < 0)
            return;

        AvatarCustomizationItem item = catalog != null ? catalog.GetItem(selectedCategory, optionIndex) : null;

        if (IsItemUnlocked(item))
        {
            SelectOption(optionIndex);
            return;
        }

        HandleLockedOptionClicked(item, optionIndex);
    }

    public void SelectOption(int optionIndex)
    {
        if (optionIndex < 0)
            return;

        switch (selectedCategory)
        {
            case AvatarCustomizationCategory.Hat:
                previewData.HatIndex = optionIndex;
                break;
            case AvatarCustomizationCategory.Face:
                previewData.FaceIndex = optionIndex;
                break;
            case AvatarCustomizationCategory.Color:
                previewData.ColorIndex = optionIndex;
                break;
        }

        ApplyPreview();
        RefreshSelectionVisuals();

        AnimateSelectionConfirmed(optionIndex);
    }

    private void AnimateSelectionConfirmed(int optionIndex)
    {
        FindButton(optionIndex)?.AnimateSelectionConfirmed();
    }

    private AvatarOptionButton[] GetButtonsForCategory(AvatarCustomizationCategory category)
    {
        return category switch
        {
            AvatarCustomizationCategory.Hat => hatButtons,
            AvatarCustomizationCategory.Face => faceButtons,
            AvatarCustomizationCategory.Color => colorButtons,
            _ => null
        };
    }

    private AvatarOptionButton FindButton(int optionIndex)
    {
        AvatarOptionButton[] buttons = GetButtonsForCategory(selectedCategory);
        if (buttons == null)
            return null;

        for (int i = 0; i < buttons.Length; i++)
        {
            AvatarOptionButton button = buttons[i];
            if (button != null && button.OptionIndex == optionIndex)
                return button;
        }

        return null;
    }

    // Confirmação e cancelamento

    public void Confirm()
    {
        PlayerManager player = PlayerManager.Instance;
        if (player == null)
        {
            Debug.LogError("CustomizationController.Confirm: PlayerManager.Instance é nulo. O avatar não foi salvo.");
            return;
        }

        // Também cobre abertura direta da cena e saves antigos.
        if (player.Profile == null)
            player.Initialize();

        if (player.Profile == null)
        {
            Debug.LogError("CustomizationController.Confirm: o perfil do jogador está indisponível. O avatar não foi salvo.");
            return;
        }

        player.Profile.Avatar ??= new AvatarCustomizationData();

        AvatarCustomizationData savedAvatar = player.Profile.Avatar;
        savedAvatar.HatIndex = previewData.HatIndex;
        savedAvatar.FaceIndex = previewData.FaceIndex;
        savedAvatar.ColorIndex = previewData.ColorIndex;

        player.SaveProfile();
        AudioManager.Instance?.PlayConfirm();

        sceneLoader?.Load(hubScene);
    }

    public void Cancel()
    {

        sceneLoader?.Load(hubScene);
    }

    public void Back() => Cancel();

    public void ConfirmPurchase()
    {
        AvatarCustomizationItem item = pendingPurchaseItem;

        if (item == null)
        {
            ShowFeedback("Nenhum item de compra selecionado.");
            AnimatePurchasePanelExit();
            return;
        }

        PlayerManager player = PlayerManager.Instance;
        if (player == null)
        {
            ShowFeedback("Sistema de jogador indisponível.");
            AnimatePurchasePanelExit();
            return;
        }

        if (item.UnlockType != AvatarUnlockType.BreakPoints)
        {
            pendingPurchaseItem = null;
            AnimatePurchasePanelExit();
            return;
        }

        if (!player.TrySpendBreakPoints(item.BreakPointCost))
        {
            ShowFeedback($"PB insuficiente. Necessário: {item.BreakPointCost} PB.");
            pendingPurchaseItem = null;
            AnimatePurchasePanelExit();
            RefreshLockVisuals();
            return;
        }

        player.UnlockCustomization(item.Id);
        player.SaveProfile();
        pendingPurchaseItem = null;

        AnimatePurchasePanelExit(() =>
        {
            SelectOption(item.OptionIndex);
            RefreshLockVisuals();
            ShowFeedback($"{DisplayNameOrFallback(item)} desbloqueado!");
            AnimateUnlockedButton(item.OptionIndex);
        });
    }

    public void CancelPurchase()
    {
        pendingPurchaseItem = null;
        AnimatePurchasePanelExit();
    }

    private void AnimateUnlockedButton(int optionIndex)
    {
        FindButton(optionIndex)?.AnimateUnlock();
    }

    private bool IsItemUnlocked(AvatarCustomizationItem item)
    {
        // Sem item no catálogo, a opção é tratada como gratuita.
        if (item == null)
            return true;

        switch (item.UnlockType)
        {
            case AvatarUnlockType.Free:
                return true;

            case AvatarUnlockType.BreakPoints:
                return PlayerManager.Instance != null && PlayerManager.Instance.IsCustomizationUnlocked(item.Id);

            case AvatarUnlockType.Level:
                return PlayerManager.Instance?.Profile != null
                    && PlayerManager.Instance.Profile.Level >= item.RequiredLevel;

            default:
                return true;
        }
    }

    private void HandleLockedOptionClicked(AvatarCustomizationItem item, int optionIndex)
    {
        if (item == null)
        {
            SelectOption(optionIndex);
            return;
        }

        if (item.UnlockType == AvatarUnlockType.Level)
        {
            if (!AnimateLockedFeedbackOnButton(
                    optionIndex,
                    () => ShowFeedback($"Disponível no nível {item.RequiredLevel}.")))
            {
                ShowFeedback($"Disponível no nível {item.RequiredLevel}.");
            }

            return;
        }

        if (item.UnlockType == AvatarUnlockType.BreakPoints)
        {
            if (!AnimateLockedFeedbackOnButton(
                    optionIndex,
                    () => OpenPurchaseConfirmation(item)))
            {
                OpenPurchaseConfirmation(item);
            }
        }
    }

    private bool AnimateLockedFeedbackOnButton(
        int optionIndex,
        System.Action onComplete = null)
    {
        AvatarOptionButton button = FindButton(optionIndex);
        if (button == null)
            return false;

        button.AnimateLockedFeedback(onComplete);
        return true;
    }

    private void OpenPurchaseConfirmation(AvatarCustomizationItem item)
    {
        pendingPurchaseItem = item;

        if (purchaseConfirmPanel == null)
        {
            ConfirmPurchase();
            return;
        }

        if (purchaseConfirmLabel != null)
            purchaseConfirmLabel.text = $"Comprar {DisplayNameOrFallback(item)} por {item.BreakPointCost} PB?";

        AnimatePurchasePanelEnter();
    }

    private void AnimatePurchasePanelEnter()
    {
        if (purchaseConfirmPanel == null) return;

        purchaseConfirmPanel.SetActive(true);

        if (!EnsurePurchasePanelReferences())
            return;

        KillPurchasePanelTween();
        _purchasePanelCanvasGroup.DOKill();
        _purchasePanelRect?.DOKill();

        _purchasePanelCanvasGroup.alpha = 0f;
        _purchasePanelRect.localScale = Vector3.one * purchasePanelEnterScale;

        _purchasePanelSequence = DOTween.Sequence();
        _purchasePanelSequence.SetUpdate(UpdateType.Late);

        _purchasePanelSequence.Join(_purchasePanelCanvasGroup.DOFade(1f, purchasePanelEnterDuration)
            .SetEase(Ease.OutQuad)
            .SetUpdate(UpdateType.Late));

        _purchasePanelSequence.Join(_purchasePanelRect.DOScale(Vector3.one, purchasePanelEnterDuration)
            .SetEase(Ease.OutBack)
            .SetUpdate(UpdateType.Late));

        _purchasePanelSequence.OnComplete(() => _purchasePanelSequence = null);
        _purchasePanelSequence.Play();
    }

    private void AnimatePurchasePanelExit(System.Action onComplete = null)
    {
        if (purchaseConfirmPanel == null)
        {
            onComplete?.Invoke();
            return;
        }

        if (!EnsurePurchasePanelReferences())
        {
            purchaseConfirmPanel.SetActive(false);
            onComplete?.Invoke();
            return;
        }

        KillPurchasePanelTween();
        _purchasePanelCanvasGroup.DOKill();
        _purchasePanelRect.DOKill();

        _purchasePanelSequence = DOTween.Sequence();
        _purchasePanelSequence.SetUpdate(UpdateType.Late);

        _purchasePanelSequence.Join(_purchasePanelCanvasGroup.DOFade(0f, purchasePanelExitDuration)
            .SetEase(Ease.InQuad)
            .SetUpdate(UpdateType.Late));

        _purchasePanelSequence.Join(_purchasePanelRect.DOScale(Vector3.one * 0.95f, purchasePanelExitDuration)
            .SetEase(Ease.InQuad)
            .SetUpdate(UpdateType.Late));

        _purchasePanelSequence.OnComplete(() =>
        {
            _purchasePanelSequence = null;
            purchaseConfirmPanel.SetActive(false);
            _purchasePanelRect.localScale = Vector3.one;
            onComplete?.Invoke();
        });

        _purchasePanelSequence.Play();
    }

    private void KillPurchasePanelTween()
    {
        if (_purchasePanelSequence != null && _purchasePanelSequence.IsActive())
            _purchasePanelSequence.Kill(false);

        _purchasePanelSequence = null;
    }

    private bool EnsurePurchasePanelReferences()
    {
        if (purchaseConfirmPanel == null)
            return false;

        _purchasePanelRect ??= purchaseConfirmPanel.transform as RectTransform;
        _purchasePanelCanvasGroup ??= purchasePanelCanvasGroup;

        return _purchasePanelRect != null && _purchasePanelCanvasGroup != null;
    }

    private static string DisplayNameOrFallback(AvatarCustomizationItem item)
    {
        return string.IsNullOrWhiteSpace(item.DisplayName) ? item.Id : item.DisplayName;
    }

    private void ShowFeedback(string message)
    {
        if (feedbackLabel == null)
            return;

        feedbackLabel.text = message;

        if (_feedbackCanvasGroup == null)
            return;

        KillFeedbackTween();
        _feedbackCanvasGroup.alpha = 0f;

        _feedbackSequence = DOTween.Sequence();
        _feedbackSequence.SetUpdate(UpdateType.Late);
        _feedbackSequence.Append(_feedbackCanvasGroup.DOFade(1f, 0.2f).SetEase(Ease.OutQuad));
        _feedbackSequence.AppendInterval(1.5f);
        _feedbackSequence.Append(_feedbackCanvasGroup.DOFade(0f, 0.3f).SetEase(Ease.InQuad));
        _feedbackSequence.OnComplete(() => _feedbackSequence = null);
        _feedbackSequence.Play();
    }

    private void KillFeedbackTween()
    {
        if (_feedbackSequence != null && _feedbackSequence.IsActive())
            _feedbackSequence.Kill();

        _feedbackSequence = null;

        if (_feedbackCanvasGroup != null)
            _feedbackCanvasGroup.alpha = 0f;
    }

    private void CopyFromSavedAvatar()
    {
        AvatarCustomizationData savedAvatar = PlayerManager.Instance?.Profile?.Avatar;
        if (savedAvatar == null)
            return;

        previewData.HatIndex = savedAvatar.HatIndex;
        previewData.FaceIndex = savedAvatar.FaceIndex;
        previewData.ColorIndex = savedAvatar.ColorIndex;
    }

    private void ApplyPreview()
    {
        avatarPreview?.Apply(previewData);
    }

    private void PlayOptionWave(bool forceLayout = true)
    {
        if (!animateOptionWave)
            return;

        OptionWaveTarget[] cachedTargets = GetWaveTargetsForCategory(selectedCategory);
        if (cachedTargets == null || cachedTargets.Length == 0)
            return;

        KillOptionWave(true);

        if (forceLayout)
            Canvas.ForceUpdateCanvases();

        _optionWaveSortBuffer.Clear();

        for (int i = 0; i < cachedTargets.Length; i++)
        {
            OptionWaveTarget target = cachedTargets[i];
            if (target == null || target.RectTransform == null ||
                !target.RectTransform.gameObject.activeInHierarchy)
                continue;

            target.FinalPosition = target.RectTransform.anchoredPosition;
            target.X = target.FinalPosition.x;
            target.Y = target.FinalPosition.y;
            _optionWaveSortBuffer.Add(target);
        }

        if (_optionWaveSortBuffer.Count == 0)
            return;

        _activeOptionWaveTargets.Clear();
        _activeOptionWaveTargets.AddRange(_optionWaveSortBuffer);

        // Ordem visual: de baixo para cima e da esquerda para a direita.
        _optionWaveSortBuffer.Sort(CompareWaveTargets);

        _optionWaveSequence = DOTween.Sequence();
        _optionWaveSequence.SetUpdate(UpdateType.Late);

        float currentDelay = 0f;
        float previousY = _optionWaveSortBuffer[0].Y;

        for (int i = 0; i < _optionWaveSortBuffer.Count; i++)
        {
            OptionWaveTarget target = _optionWaveSortBuffer[i];

            if (i > 0)
            {
                bool newRow = !Mathf.Approximately(target.Y, previousY);
                currentDelay += newRow ? optionWaveRowDelay : optionWaveItemDelay;
            }

            previousY = target.Y;

            target.CanvasGroup.DOKill();
            target.RectTransform.DOKill();

            target.CanvasGroup.alpha = 0f;
            target.RectTransform.anchoredPosition =
                target.FinalPosition + Vector2.down * optionWaveStartOffset;

            Tween moveTween = target.RectTransform
                .DOAnchorPos(target.FinalPosition, optionWaveDuration)
                .SetEase(optionWaveEase)
                .SetUpdate(UpdateType.Late);

            Tween fadeTween = target.CanvasGroup
                .DOFade(1f, optionWaveDuration * 0.75f)
                .SetEase(Ease.OutQuad)
                .SetUpdate(UpdateType.Late);

            _optionWaveSequence.Insert(currentDelay, moveTween);
            _optionWaveSequence.Insert(currentDelay, fadeTween);
        }

        _optionWaveSequence.OnComplete(() =>
        {
            for (int i = 0; i < _activeOptionWaveTargets.Count; i++)
            {
                OptionWaveTarget target = _activeOptionWaveTargets[i];
                if (target.RectTransform != null)
                    target.RectTransform.anchoredPosition = target.FinalPosition;
                if (target.CanvasGroup != null)
                    target.CanvasGroup.alpha = 1f;
            }

            _activeOptionWaveTargets.Clear();
            _optionWaveSequence = null;
        });

        _optionWaveSequence.Play();
    }

    private static int CompareWaveTargets(OptionWaveTarget a, OptionWaveTarget b)
    {
        int yCompare = a.Y.CompareTo(b.Y);
        return yCompare != 0 ? yCompare : a.X.CompareTo(b.X);
    }

    private void KillOptionWave(bool restoreTargets)
    {
        if (_optionWaveSequence != null && _optionWaveSequence.IsActive())
        {
            _optionWaveSequence.Kill(false);
        }

        _optionWaveSequence = null;

        if (!restoreTargets)
        {
            _activeOptionWaveTargets.Clear();
            return;
        }

        for (int i = 0; i < _activeOptionWaveTargets.Count; i++)
        {
            OptionWaveTarget target = _activeOptionWaveTargets[i];
            if (target == null)
                continue;

            if (target.RectTransform != null)
            {
                target.RectTransform.DOKill();
                target.RectTransform.anchoredPosition = target.FinalPosition;
            }

            if (target.CanvasGroup != null)
            {
                target.CanvasGroup.DOKill();
                target.CanvasGroup.alpha = 1f;
            }
        }

        _activeOptionWaveTargets.Clear();
    }

    private void RefreshVisibleOptions()
    {
        SetOptionsVisible(hatOptions, selectedCategory == AvatarCustomizationCategory.Hat);
        SetOptionsVisible(faceOptions, selectedCategory == AvatarCustomizationCategory.Face);
        SetOptionsVisible(colorOptions, selectedCategory == AvatarCustomizationCategory.Color);
    }

    private static void SetOptionsVisible(GameObject[] options, bool visible)
    {
        if (options == null)
            return;

        for (int i = 0; i < options.Length; i++)
        {
            if (options[i] != null && options[i].activeSelf != visible)
                options[i].SetActive(visible);
        }
    }

    private void RefreshLockVisuals()
    {
        RefreshCategoryLockVisuals(AvatarCustomizationCategory.Hat, hatButtons);
        RefreshCategoryLockVisuals(AvatarCustomizationCategory.Face, faceButtons);
        RefreshCategoryLockVisuals(AvatarCustomizationCategory.Color, colorButtons);
    }

    private void RefreshCategoryLockVisuals(AvatarCustomizationCategory category, AvatarOptionButton[] buttons)
    {
        if (buttons == null)
            return;

        for (int i = 0; i < buttons.Length; i++)
        {
            AvatarOptionButton optionButton = buttons[i];
            if (optionButton == null)
                continue;

            AvatarCustomizationItem item = catalog != null ? catalog.GetItem(category, optionButton.OptionIndex) : null;
            bool isLocked = !IsItemUnlocked(item);
            optionButton.SetLocked(isLocked, BuildLockLabel(item));
        }
    }

    private void RefreshSelectionVisuals()
    {
        RefreshCategorySelectionVisuals(hatButtons, previewData.HatIndex);
        RefreshCategorySelectionVisuals(faceButtons, previewData.FaceIndex);
        RefreshCategorySelectionVisuals(colorButtons, previewData.ColorIndex);
    }

    private static void RefreshCategorySelectionVisuals(
        AvatarOptionButton[] buttons,
        int selectedIndex)
    {
        if (buttons == null)
            return;

        for (int i = 0; i < buttons.Length; i++)
        {
            AvatarOptionButton optionButton = buttons[i];
            if (optionButton != null)
                optionButton.SetSelected(optionButton.OptionIndex == selectedIndex);
        }
    }

    private void CacheOptionButtons()
    {
        hatButtons = ExtractButtons(hatOptions);
        faceButtons = ExtractButtons(faceOptions);
        colorButtons = ExtractButtons(colorOptions);
    }

    private void CacheOptionWaveTargets()
    {
        if (!animateOptionWave)
        {
            hatWaveTargets = System.Array.Empty<OptionWaveTarget>();
            faceWaveTargets = System.Array.Empty<OptionWaveTarget>();
            colorWaveTargets = System.Array.Empty<OptionWaveTarget>();
            return;
        }

        hatWaveTargets = BuildWaveTargets(hatButtons);
        faceWaveTargets = BuildWaveTargets(faceButtons);
        colorWaveTargets = BuildWaveTargets(colorButtons);
    }

    private static OptionWaveTarget[] BuildWaveTargets(AvatarOptionButton[] buttons)
    {
        if (buttons == null || buttons.Length == 0)
            return System.Array.Empty<OptionWaveTarget>();

        OptionWaveTarget[] targets = new OptionWaveTarget[buttons.Length];
        for (int i = 0; i < buttons.Length; i++)
        {
            AvatarOptionButton button = buttons[i];
            if (button == null)
                continue;

            RectTransform rect = button.GetComponent<RectTransform>();
            CanvasGroup canvasGroup = button.GetComponent<CanvasGroup>();
            if (canvasGroup == null)
                continue;

            targets[i] = new OptionWaveTarget
            {
                RectTransform = rect,
                CanvasGroup = canvasGroup
            };
        }

        return targets;
    }

    private OptionWaveTarget[] GetWaveTargetsForCategory(AvatarCustomizationCategory category)
    {
        return category switch
        {
            AvatarCustomizationCategory.Hat => hatWaveTargets,
            AvatarCustomizationCategory.Face => faceWaveTargets,
            AvatarCustomizationCategory.Color => colorWaveTargets,
            _ => null
        };
    }

    private static AvatarOptionButton[] ExtractButtons(GameObject[] options)
    {
        if (options == null)
            return System.Array.Empty<AvatarOptionButton>();

        var buttons = new AvatarOptionButton[options.Length];
        for (int i = 0; i < options.Length; i++)
        {
            if (options[i] != null)
                buttons[i] = options[i].GetComponent<AvatarOptionButton>();
        }

        return buttons;
    }

    private static string BuildLockLabel(AvatarCustomizationItem item)
    {
        if (item == null)
            return string.Empty;

        return item.UnlockType switch
        {
            AvatarUnlockType.BreakPoints => $"{item.BreakPointCost} PB",
            AvatarUnlockType.Level => $"Nv. {item.RequiredLevel}",
            _ => string.Empty
        };
    }

    private void BindButtons()
    {
        if (_buttonsBound)
            return;

        confirmButton?.onClick.AddListener(Confirm);
        purchaseConfirmYesButton?.onClick.AddListener(ConfirmPurchase);
        purchaseConfirmNoButton?.onClick.AddListener(CancelPurchase);
        _buttonsBound = true;
    }

    private void UnbindButtons()
    {
        if (!_buttonsBound)
            return;

        confirmButton?.onClick.RemoveListener(Confirm);
        purchaseConfirmYesButton?.onClick.RemoveListener(ConfirmPurchase);
        purchaseConfirmNoButton?.onClick.RemoveListener(CancelPurchase);
        _buttonsBound = false;
    }
}
