using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(RectTransform))]
[RequireComponent(typeof(CanvasGroup))]
public sealed class DraggableInteraction : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [Header("Dados da interação")]
    [SerializeField] private string interactionId = "interaction_01";
    [SerializeField] private string reactionTrigger = "Happy";
    [SerializeField, TextArea] private string feedbackMessage = "";

    [Header("Retorno ao slot")]
    [SerializeField, Min(0f)] private float returnDuration = 0.15f;

    [Header("Estado visual bloqueado")]
    [Tooltip("Arte do card. Se não for atribuída, o filho cujo nome começa com 'Card' será usado.")]
    [SerializeField] private GameObject cardVisual;
    [Tooltip("Contorno tracejado do slot. Se não for atribuído, o filho cujo nome começa com 'Slot' será usado.")]
    [SerializeField] private GameObject slotVisual;
    [Tooltip("Imagem atual do card. Se não for atribuída, o filho chamado 'Icon' será localizado automaticamente.")]
    [SerializeField] private Image icon;
    [Tooltip("Imagem usada quando a barra da Energy Station chega a 100%.")]
    [SerializeField] private Sprite icon2;
    [SerializeField] private Color lockedTint = new Color(0.28f, 0.28f, 0.28f, 1f);

    private RectTransform rectTransform;
    private CanvasGroup canvasGroup;
    private Transform originParent;
    private Vector3 originLocalPosition;
    private Quaternion originLocalRotation;
    private Vector3 originLocalScale;
    private Canvas interactionCanvas;
    private bool hasOrigin;
    private bool accepted;
    private bool sessionLocked;
    private bool dragInProgress;
    private Coroutine returnRoutine;
    private Graphic[] cardGraphics;
    private Color[] originalGraphicColors;
    private Sprite originalIconSprite;
    private bool originalIconCached;

    public string InteractionId => interactionId;
    public string ReactionTrigger => reactionTrigger;
    public string FeedbackMessage => feedbackMessage;
    public bool IsAvailable => !accepted && !sessionLocked && gameObject.activeInHierarchy;

    public event System.Action<DraggableInteraction> DragStarted;
    public event System.Action<DraggableInteraction> ReturnedToOrigin;

    private void Awake()
    {
        CacheComponents();
        CacheOrigin();
        CacheVisualReferences();
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (accepted || sessionLocked)
            return;

        StopReturnRoutine(completeReturn: false);
        dragInProgress = true;

        if (!hasOrigin || transform.parent == originParent)
            CacheOrigin();

        canvasGroup.blocksRaycasts = false;
        AudioManager.Instance?.PlayEnergyDrag();

        if (interactionCanvas != null && transform.parent != interactionCanvas.transform)
            transform.SetParent(interactionCanvas.transform, true);

        transform.SetAsLastSibling();
        DragStarted?.Invoke(this);
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (!dragInProgress || interactionCanvas == null)
            return;

        RectTransform canvasRect = interactionCanvas.transform as RectTransform;
        if (canvasRect == null)
            return;

        Camera eventCamera = interactionCanvas.renderMode == RenderMode.ScreenSpaceOverlay
            ? null
            : eventData.pressEventCamera;

        if (RectTransformUtility.ScreenPointToWorldPointInRectangle(
                canvasRect,
                eventData.position,
                eventCamera,
                out Vector3 worldPoint))
        {
            rectTransform.position = worldPoint;
        }
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (!dragInProgress)
            return;

        dragInProgress = false;
        canvasGroup.blocksRaycasts = true;

        if (!accepted)
            returnRoutine = StartCoroutine(ReturnToOrigin());
    }

    public void AcceptDrop()
    {
        StopReturnRoutine(completeReturn: false);
        accepted = true;
        dragInProgress = false;

        if (originParent != null)
            transform.SetParent(originParent, false);

        ApplyOriginTransform();
        CacheVisualReferences();
        if (slotVisual != null)
            slotVisual.SetActive(true);
        if (cardVisual != null)
            cardVisual.SetActive(false);
        ApplyLockedTint(false);

        canvasGroup.interactable = false;
        canvasGroup.blocksRaycasts = false;
    }

    public void LockForSessionEnd(bool showCompletedIcon = false)
    {
        CacheComponents();
        CacheVisualReferences();
        StopReturnRoutine(completeReturn: false);
        dragInProgress = false;
        sessionLocked = true;

        if (originParent != null)
            transform.SetParent(originParent, false);
        ApplyOriginTransform();

        if (slotVisual != null)
            slotVisual.SetActive(true);
        if (cardVisual != null)
            cardVisual.SetActive(!accepted);

        bool usingIcon2 = ApplyIcon(showCompletedIcon);
        ApplyLockedTint(!accepted && !usingIcon2);

        canvasGroup.interactable = false;
        canvasGroup.blocksRaycasts = false;
    }

    public void ResetToOrigin()
    {
        // Alguns cards começam inativos, então o primeiro reset pode acontecer antes do Awake.
        CacheComponents();
        CacheVisualReferences();
        StopReturnRoutine(completeReturn: true);
        accepted = false;
        sessionLocked = false;
        dragInProgress = false;

        if (!hasOrigin)
            CacheOrigin();

        if (!gameObject.activeSelf)
            gameObject.SetActive(true);

        if (originParent != null)
            transform.SetParent(originParent, false);

        ApplyOriginTransform();
        canvasGroup.alpha = 1f;
        canvasGroup.interactable = true;
        canvasGroup.blocksRaycasts = true;
        if (slotVisual != null)
            slotVisual.SetActive(true);
        if (cardVisual != null)
            cardVisual.SetActive(true);
        ApplyIcon(false);
        ApplyLockedTint(false);
    }

    private void CacheOrigin()
    {
        CacheComponents();
        if (rectTransform == null)
            return;

        originParent = transform.parent;
        originLocalPosition = rectTransform.localPosition;
        originLocalRotation = rectTransform.localRotation;
        originLocalScale = rectTransform.localScale;
        hasOrigin = originParent != null;
    }

    private void CacheComponents()
    {
        if (rectTransform == null)
            rectTransform = transform as RectTransform;

        if (canvasGroup == null)
            canvasGroup = GetComponent<CanvasGroup>();

        // Usa o Canvas interativo para manter o card acima do tutorial durante o arraste.
        if (interactionCanvas == null)
            interactionCanvas = GetComponentInParent<Canvas>(true);
    }

    private void CacheVisualReferences()
    {
        if (cardVisual == null || slotVisual == null)
        {
            for (int i = 0; i < transform.childCount; i++)
            {
                GameObject child = transform.GetChild(i).gameObject;
                if (slotVisual == null && child.name.StartsWith("Slot", System.StringComparison.Ordinal))
                    slotVisual = child;
                else if (cardVisual == null && child.name.StartsWith("Card", System.StringComparison.Ordinal))
                    cardVisual = child;
            }
        }

        if (icon == null && cardVisual != null)
        {
            Image[] images = cardVisual.GetComponentsInChildren<Image>(true);
            for (int i = 0; i < images.Length; i++)
            {
                if (images[i].name.Equals("Icon", System.StringComparison.Ordinal))
                {
                    icon = images[i];
                    break;
                }
            }
        }

        if (icon != null && !originalIconCached)
        {
            originalIconSprite = icon.sprite;
            originalIconCached = true;
        }

        if (cardVisual == null || cardGraphics != null)
            return;

        cardGraphics = cardVisual.GetComponentsInChildren<Graphic>(true);
        originalGraphicColors = new Color[cardGraphics.Length];
        for (int i = 0; i < cardGraphics.Length; i++)
            originalGraphicColors[i] = cardGraphics[i].color;
    }

    private bool ApplyIcon(bool completed)
    {
        CacheVisualReferences();

        if (icon == null)
            return false;

        if (completed && icon2 != null)
        {
            icon.sprite = icon2;
            icon.preserveAspect = true;
            return true;
        }

        if (originalIconCached)
            icon.sprite = originalIconSprite;

        icon.preserveAspect = true;
        return false;
    }

    private void ApplyLockedTint(bool locked)
    {
        if (cardGraphics == null || originalGraphicColors == null)
            return;

        for (int i = 0; i < cardGraphics.Length; i++)
        {
            Color original = originalGraphicColors[i];
            cardGraphics[i].color = locked
                ? new Color(
                    original.r * lockedTint.r,
                    original.g * lockedTint.g,
                    original.b * lockedTint.b,
                    original.a)
                : original;
        }
    }

    private IEnumerator ReturnToOrigin()
    {
        Vector3 start = rectTransform.position;
        Vector3 target = originParent != null
            ? originParent.TransformPoint(originLocalPosition)
            : start;
        float elapsed = 0f;

        while (elapsed < returnDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float t = returnDuration <= 0f
                ? 1f
                : Mathf.Clamp01(elapsed / returnDuration);

            rectTransform.position = Vector3.Lerp(start, target, t);
            yield return null;
        }

        if (originParent != null)
        {
            transform.SetParent(originParent, false);
            ApplyOriginTransform();
        }
        else
        {
            rectTransform.position = target;
        }

        returnRoutine = null;
        ReturnedToOrigin?.Invoke(this);
    }

    private void StopReturnRoutine(bool completeReturn)
    {
        bool wasReturning = returnRoutine != null;
        if (wasReturning)
        {
            StopCoroutine(returnRoutine);
            returnRoutine = null;
        }

        if (!completeReturn || originParent == null)
            return;

        transform.SetParent(originParent, false);
        ApplyOriginTransform();
    }

    private void ApplyOriginTransform()
    {
        rectTransform.localPosition = originLocalPosition;
        rectTransform.localRotation = originLocalRotation;
        rectTransform.localScale = originLocalScale;
    }

    private void OnDisable()
    {
        // Evita reparentear durante OnDisable; o Unity ainda está desmontando a hierarquia.
        StopReturnRoutine(completeReturn: false);
        dragInProgress = false;
        rectTransform.localScale = hasOrigin ? originLocalScale : Vector3.one;
        canvasGroup.alpha = 1f;
        canvasGroup.interactable = !accepted && !sessionLocked;
        canvasGroup.blocksRaycasts = !accepted && !sessionLocked;
    }
}
