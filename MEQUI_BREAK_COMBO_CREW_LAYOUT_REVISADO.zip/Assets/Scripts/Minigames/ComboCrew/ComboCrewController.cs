using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>Pedidos, funcionários e bandejas do Combo Crew; todos os visuais são da Hierarchy.</summary>
[DisallowMultipleComponent]
public sealed class ComboCrewController : MonoBehaviour
{
    private const int MainStationCount = 4;
    private const int WashStation = 4;
    private enum OrderState { Free, Working, Travelling, Resolving }
    private sealed class Order
    {
        public OrderState State;
        public int Sequence, Stage, Items;
        public float Patience, Remaining, Progress;
        public float ReadyHold;
        public bool HasTray;
    }

    [Header("Sessão e HUD")]
    [SerializeField] private SceneLoader sceneLoader;
    [SerializeField] private ResultPopup resultPopup;
    [SerializeField] private Button startButton;
    [SerializeField] private Button backButton;
    [SerializeField] private GameObject preparationPanel;
    [SerializeField] private TMP_Text timerLabel;
    [SerializeField] private TMP_Text messageLabel;
    [SerializeField] private TMP_Text cleanTrayLabel;
    [SerializeField] private TMP_Text dirtyTrayLabel;
    [SerializeField] private ComboCrewClipboard clipboard;
    [SerializeField, Min(1f)] private float preparationSeconds = 12f;
    [SerializeField, Min(1f)] private float matchSeconds = 70f;
    [SerializeField, Min(.1f)] private float spawnInterval = 6f;
    [SerializeField, Min(1f)] private float patienceSeconds = 42f;
    [SerializeField, Min(.1f)] private float stageSeconds = 4f;
    [SerializeField, Range(0f, 1f)] private float secondOrderSpeed = .5f;
    [SerializeField, Min(1)] private int initialTrays = 4;
    [SerializeField, Min(.1f)] private float washSecondsPerTray = 1.4f;
    [SerializeField, Min(0)] private int completionPoints = 20;

    [Header("Referências montadas no Canvas")]
    [Tooltip("Ordem: Preparo, Chapa, Montagem, Entrega, Lava-louça. A posição visual pode ser em S.")]
    [SerializeField] private ComboCrewStationView[] stations;
    [Tooltip("Índice zero é o personagem do jogador; os demais são funcionários.")]
    [SerializeField] private ComboCrewWorkerView[] workers;
    [Tooltip("Um card por personagem; o índice zero representa o jogador.")]
    [SerializeField] private ComboCrewWorkerCard[] workerCards;
    [SerializeField] private RectTransform[] cardAnchors;
    [SerializeField] private ComboCrewOrderView[] orderCards;
    [SerializeField] private RectTransform[] orderAnchors;
    [SerializeField] private RectTransform departureAnchor;

    private Order[] orders;
    private int[] assigned;
    private int[] stationWorker;
    private bool[] moving;
    private float prepareRemaining, matchRemaining, nextSpawn;
    private int nextSequence, delivered, missed, cleanTrays, dirtyTrays;
    private bool preparing, playing, closing, settled, leaving, paused, logged;
    private int washingCount;

    public bool CanMoveWorker(int index) => (preparing || playing) && !leaving && !settled
        && index >= 0 && index < workers.Length && workers[index] != null && !workers[index].Busy;
    public RectTransform CardHome(int index) => cardAnchors != null && index >= 0
        && index < cardAnchors.Length ? cardAnchors[index] : null;

    private void Awake()
    {
        if (startButton != null) startButton.onClick.AddListener(StartMatch);
        if (backButton != null) backButton.onClick.AddListener(BackToHub);
        if (preparationPanel != null) preparationPanel.SetActive(true);
    }

    private void OnEnable() => SceneLoader.SceneLeaving += SceneLeaving;

    private void Start()
    {
        UnityEngine.Device.Screen.orientation = ScreenOrientation.Portrait;
        if (!Validate()) { ShowMessage("Configuração incompleta. Consulte o Console."); return; }
        orders = new Order[orderCards.Length];
        for (int i = 0; i < orders.Length; i++)
        {
            orders[i] = new Order();
            orderCards[i].gameObject.SetActive(false);
        }
        assigned = new int[workers.Length];
        moving = new bool[workers.Length];
        stationWorker = new int[stations.Length];
        for (int i = 0; i < workers.Length; i++) assigned[i] = -1;
        for (int i = 0; i < stations.Length; i++)
        {
            stationWorker[i] = -1;
            stations[i].Bind(this, i);
        }
        cleanTrays = initialTrays;
        workers[0].ApplyPlayerAppearance();
        prepareRemaining = preparationSeconds;
        preparing = true;
        RefreshHud();
    }

    private bool Validate()
    {
        string error = sceneLoader == null ? "SceneLoader" : resultPopup == null ? "ResultPopup" :
            startButton == null ? "StartButton" : backButton == null ? "BackButton" :
            preparationPanel == null ? "PreparationPanel" :
            timerLabel == null ? "TimerLabel" : messageLabel == null ? "MessageLabel" :
            cleanTrayLabel == null || dirtyTrayLabel == null ? "contadores de bandejas" :
            clipboard == null || !clipboard.Configured ? "Clipboard" :
            stations == null || stations.Length != 5 ? "cinco estações" :
            workers == null || workers.Length < 2 ? "jogador + funcionários" :
            workerCards == null || workerCards.Length != workers.Length ? "cards dos funcionários" :
            cardAnchors == null || cardAnchors.Length != workers.Length ? "âncoras dos cards" :
            orderCards == null || orderCards.Length < 2 ? "cards dos pedidos" :
            orderAnchors == null || orderAnchors.Length != orderCards.Length ? "âncoras dos pedidos" :
            departureAnchor == null ? "saída dos pedidos" :
            PlayerManager.Instance == null || PlayerManager.Instance.Profile == null ? "perfil (entre pelo Boot)" :
            PointsService.Instance == null || EventLogger.Instance == null ? "serviços do Boot" : null;
        if (error == null)
        {
            for (int i = 0; i < stations.Length; i++)
                if (stations[i] == null || !stations[i].Configured) { error = $"station[{i}]"; break; }
        }
        if (error == null)
        {
            for (int i = 0; i < workers.Length; i++)
                if (workers[i] == null || !workers[i].Configured || cardAnchors[i] == null
                    || workerCards[i] == null || !workerCards[i].Configured)
                { error = $"worker[{i}] e seu card"; break; }
        }
        if (error == null && (preparationSeconds <= 0f || matchSeconds <= 0f
            || spawnInterval <= 0f || patienceSeconds <= 0f || stageSeconds <= 0f
            || initialTrays < 1 || washSecondsPerTray <= 0f)) error = "tempos ou bandejas iniciais";
        if (error == null)
        {
            for (int i = 0; i < orderCards.Length; i++)
                if (orderCards[i] == null || !orderCards[i].Configured || orderAnchors[i] == null)
                { error = $"order[{i}]"; break; }
        }
        if (error == null) return true;
        Debug.LogError("Combo Crew: configure " + error, this);
        if (startButton != null) startButton.interactable = false;
        return false;
    }

    private void Update()
    {
        if (leaving || settled || paused || SceneLoader.IsTransitionInProgress || orders == null) return;
        if (preparing)
        {
            prepareRemaining = Mathf.Max(0f, prepareRemaining - Time.deltaTime);
            RefreshHud();
            if (prepareRemaining <= 0f) StartMatch();
            return;
        }
        if (!playing) return;
        float delta = Time.deltaTime;
        if (!closing)
        {
            matchRemaining = Mathf.Max(0f, matchRemaining - delta);
            nextSpawn -= delta;
            if (nextSpawn <= 0f && matchRemaining > 0f && TrySpawn()) nextSpawn = spawnInterval;
            if (matchRemaining <= 0f)
            {
                closing = true;
                EventLogger.Instance?.MarkTimeLimitReached();
                ShowMessage("Últimos pedidos em andamento");
            }
        }
        for (int i = 0; i < orders.Length; i++)
        {
            Order order = orders[i];
            if (order.State == OrderState.Free || order.State == OrderState.Resolving) continue;
            order.Remaining = Mathf.Max(0f, order.Remaining - delta);
            if (order.Remaining <= 0f) { Resolve(i, false); continue; }
            if (order.State == OrderState.Working) Advance(i, delta);
        }
        if (washingCount == 0 && dirtyTrays > 0) StartWashing();
        RefreshHud();
        if (closing) TryFinish();
    }

    public void StartMatch()
    {
        if (!preparing || orders == null || leaving) return;
        preparing = false;
        playing = true;
        preparationPanel.SetActive(false);
        matchRemaining = matchSeconds;
        nextSpawn = spawnInterval;
        EventLogger.Instance.BeginSession("combo_crew");
        logged = true;
        EventLogger.Instance.RecordUserAction("combo_start");
        TrySpawn();
        AudioManager.Instance?.PlayConfirm();
        RefreshHud();
    }

    private bool TrySpawn()
    {
        for (int i = 0; i < orders.Length; i++)
        {
            if (orders[i].State != OrderState.Free) continue;
            Order order = orders[i];
            order.State = OrderState.Working;
            order.Sequence = nextSequence++;
            order.Stage = 0;
            order.Items = 1 + (order.Sequence % 3);
            order.Patience = patienceSeconds;
            order.Remaining = order.Patience;
            order.Progress = 0f;
            order.ReadyHold = 0f;
            order.HasTray = false;
            orderCards[i].Show(order.Items, orderAnchors[Rank(i)]);
            EventLogger.Instance?.RecordActivityEvent("combo_order_created");
            return true;
        }
        return false;
    }

    private void Advance(int id, float delta)
    {
        Order order = orders[id];
        int stage = order.Stage;
        int employee = stationWorker[stage];
        if (employee < 0 || moving[employee] || workers[employee].Busy || FirstAtStage(stage) != id) return;
        int rank = Rank(id);
        float speed = rank == 0 ? 1f : rank == 1 ? secondOrderSpeed : 0f;
        if (speed <= 0f) return;
        if (order.Progress < 1f)
            order.Progress = Mathf.Min(1f, order.Progress + delta * speed / stageSeconds);
        if (order.Progress >= 1f) order.ReadyHold += delta;
        if (order.Progress < 1f || order.ReadyHold < .18f || (stage == 0 && cleanTrays < 1)) return;
        if (stage < MainStationCount - 1 && StageOccupied(stage + 1, id)) return;
        if (stage == 0) cleanTrays--;
        order.HasTray = true;
        order.State = OrderState.Travelling;
        moving[employee] = true;
        if (stage == MainStationCount - 1)
        {
            workers[employee].Deliver(departureAnchor, () =>
            {
                moving[employee] = false;
                if (playing && order.State == OrderState.Travelling) Resolve(id, true);
            });
            return;
        }
        workers[employee].Travel(stations[stage + 1].HandoffAnchor, () =>
        {
            if (!playing || order.State != OrderState.Travelling) return;
            order.Stage = stage + 1;
            order.Progress = 0f;
            order.ReadyHold = 0f;
            order.State = OrderState.Working;
            stations[stage].ResetProgress();
            AudioManager.Instance?.PlayConfirm();
        }, () => moving[employee] = false);
    }

    private int FirstAtStage(int stage)
    {
        int result = -1, sequence = int.MaxValue;
        for (int i = 0; i < orders.Length; i++)
            if (orders[i].State == OrderState.Working && orders[i].Stage == stage
                && orders[i].Sequence < sequence) { result = i; sequence = orders[i].Sequence; }
        return result;
    }

    private int VisibleAtStage(int stage)
    {
        int id = FirstAtStage(stage);
        if (id >= 0) return id;
        for (int i = 0; i < orders.Length; i++)
            if (orders[i].State == OrderState.Travelling && orders[i].Stage == stage) return i;
        return -1;
    }

    private bool StageOccupied(int stage, int except)
    {
        for (int i = 0; i < orders.Length; i++)
            if (i != except && (orders[i].State == OrderState.Working || orders[i].State == OrderState.Travelling)
                && orders[i].Stage == stage) return true;
        return false;
    }

    private void StartWashing()
    {
        int employee = stationWorker[WashStation];
        if (employee < 0 || workers[employee].Busy || moving[employee]) return;
        int batch = dirtyTrays;
        dirtyTrays = 0;
        washingCount = batch;
        moving[employee] = true;
        workers[employee].Wash(stations[3].HandoffAnchor, stations[0].HandoffAnchor,
            batch, washSecondsPerTray, () =>
            {
                moving[employee] = false;
                cleanTrays += washingCount;
                washingCount = 0;
                AudioManager.Instance?.PlayReady();
                RefreshHud();
                TryFinish();
            });
    }

    private void Resolve(int id, bool success)
    {
        Order order = orders[id];
        if (order.State == OrderState.Free || order.State == OrderState.Resolving) return;
        order.State = OrderState.Resolving;
        if (success) { delivered++; dirtyTrays++; AudioManager.Instance?.PlayConfirm(); }
        else { missed++; if (order.HasTray) dirtyTrays++; AudioManager.Instance?.PlayError(); }
        EventLogger.Instance?.RecordActivityEvent(success ? "combo_order_delivered" : "combo_order_missed");
        orderCards[id].Resolve(success, () =>
        {
            order.State = OrderState.Free;
            order.HasTray = false;
            order.Progress = 0f;
            TryFinish();
        });
        RefreshHud();
    }

    private int Rank(int id)
    {
        int rank = 0;
        for (int i = 0; i < orders.Length; i++)
            if (i != id && orders[i].State != OrderState.Free
                && orders[i].Sequence < orders[id].Sequence) rank++;
        return rank;
    }

    public bool AssignWorker(int worker, int station)
    {
        if ((!preparing && !playing) || worker < 0 || worker >= workers.Length
            || station < 0 || station >= stations.Length || workers[worker].Busy || moving[worker]) return false;
        int old = assigned[worker];
        if (old == station) return true;
        int occupant = stationWorker[station];
        if (occupant >= 0 && occupant != worker)
        {
            if (old < 0 || workers[occupant].Busy || moving[occupant])
            { ShowMessage("Esta bancada já tem alguém."); return false; }
            assigned[occupant] = old;
            workers[occupant].Place(stations[old].WorkAnchor, false);
        }
        if (old >= 0) stationWorker[old] = occupant;
        assigned[worker] = station;
        stationWorker[station] = worker;
        workers[worker].Place(stations[station].WorkAnchor, false);
        EventLogger.Instance?.RecordUserAction(worker == 0 ? "combo_player_move" : "combo_assign_worker");
        AudioManager.Instance?.PlayConfirm();
        MequiHaptics.Selection();
        HighlightStations(false);
        return true;
    }

    public void HighlightStations(bool visible)
    {
        if (stations == null || stationWorker == null) return;
        for (int i = 0; i < stations.Length; i++)
            stations[i].Highlight(visible && stationWorker[i] < 0);
    }

    private void TryFinish()
    {
        if (!closing || settled || washingCount > 0) return;
        for (int i = 0; i < orders.Length; i++) if (orders[i].State != OrderState.Free) return;
        settled = true;
        playing = false;
        backButton.interactable = false;
        int points = PointsService.Instance.AwardParticipation(completionPoints);
        PlayerManager.Instance.SetPendingPoints(points, "ComboCrew");
        EventLogger.Instance?.RecordActivityEvent($"combo_result_{delivered}_{missed}");
        EventLogger.Instance?.CompleteSession();
        logged = false;
        AudioManager.Instance?.PlayCompletion();
        resultPopup.Show(points, delivered, missed);
    }

    private void RefreshHud()
    {
        if (timerLabel != null)
        {
            int seconds = Mathf.CeilToInt(preparing ? prepareRemaining : matchRemaining);
            timerLabel.SetText("{0}:{1:00}", seconds / 60, seconds % 60);
        }
        if (cleanTrayLabel != null) cleanTrayLabel.SetText("LIMPAS {0}", cleanTrays);
        if (dirtyTrayLabel != null) dirtyTrayLabel.SetText("SUJAS {0}", dirtyTrays);
        if (orders == null) return;
        for (int i = 0; i < orders.Length; i++)
        {
            Order order = orders[i];
            if (order.State != OrderState.Free && order.State != OrderState.Resolving)
                orderCards[i].Refresh(order.Remaining / order.Patience, orderAnchors[Rank(i)]);
        }
        for (int stage = 0; stage < stations.Length; stage++)
        {
            int id = VisibleAtStage(stage);
            if (stage == WashStation)
                stations[stage].Refresh(washingCount > 0 && stationWorker[stage] >= 0
                        ? workers[stationWorker[stage]].RouteProgress : 0f,
                    washingCount > 0 ? "Lavando" : dirtyTrays > 0 ? "Bandejas aguardando" : "Livre", false);
            else
                stations[stage].Refresh(id < 0 ? 0f : orders[id].Progress,
                    stationWorker[stage] < 0 ? "Sem funcionário" : id < 0 ? "Pronta"
                        : orders[id].State == OrderState.Travelling ? "Transportando" : "Preparando",
                    (id >= 0 && orders[id].State == OrderState.Working
                        && (orders[id].HasTray || (stage == 0 && cleanTrays > 0)))
                    || (stage == 3 && dirtyTrays > 0));
        }
    }

    private void ShowMessage(string text) { if (messageLabel != null) messageLabel.text = text; }

    public void BackToHub()
    {
        if (leaving || settled || sceneLoader == null) return;
        leaving = true;
        Abandon();
        sceneLoader.Load("HUB");
    }

    private void Abandon()
    {
        if (!logged) return;
        logged = false;
        EventLogger.Instance?.AbandonSession();
    }

    private void SceneLeaving(Scene scene)
    {
        if (scene != gameObject.scene) return;
        leaving = true;
        Abandon();
    }

    private void OnApplicationPause(bool value)
    {
        paused = value;
        if (workers == null) return;
        foreach (ComboCrewWorkerView worker in workers)
            if (worker != null) worker.SetPaused(value);
    }
    private void OnDisable()
    {
        SceneLoader.SceneLeaving -= SceneLeaving;
        leaving = true;
        Abandon();
        DOTween.Kill(this);
    }

    private void OnDestroy()
    {
        if (startButton != null) startButton.onClick.RemoveListener(StartMatch);
        if (backButton != null) backButton.onClick.RemoveListener(BackToHub);
    }
}
