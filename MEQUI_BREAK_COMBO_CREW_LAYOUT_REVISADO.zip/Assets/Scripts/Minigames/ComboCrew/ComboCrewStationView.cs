using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>Bancada fixa e alvo de funcionários. A barra segue o valor lógico recebido.</summary>
[DisallowMultipleComponent]
public sealed class ComboCrewStationView : MonoBehaviour, IDropHandler
{
    [SerializeField] private RectTransform workAnchor;
    [SerializeField] private RectTransform handoffAnchor;
    [SerializeField] private Image progressFill;
    [SerializeField] private Image highlight;
    [SerializeField] private TMP_Text status;
    [SerializeField] private GameObject trayOnCounter;
    private ComboCrewController owner;
    private int index;
    private float shown;
    private RectTransform bar;
    public RectTransform WorkAnchor => workAnchor;
    public RectTransform HandoffAnchor => handoffAnchor;
    public bool Configured => workAnchor != null && progressFill != null && highlight != null
        && handoffAnchor != null && status != null && trayOnCounter != null;

    public void Bind(ComboCrewController controller, int stationIndex)
    {
        owner = controller;
        index = stationIndex;
        shown = 0f;
        bar = progressFill.rectTransform;
        progressFill.type = Image.Type.Simple;
        SetBar(0f);
        highlight.gameObject.SetActive(false);
        trayOnCounter.SetActive(false);
    }

    public void Refresh(float progress, string message, bool hasTray)
    {
        float blend = 1f - Mathf.Exp(-10f * Time.unscaledDeltaTime);
        shown = Mathf.Lerp(shown, Mathf.Clamp01(progress), blend);
        SetBar(shown);
        status.text = message;
        trayOnCounter.SetActive(hasTray);
    }

    private void SetBar(float value)
    {
        Vector3 scale = bar.localScale;
        scale.x = Mathf.Clamp01(value);
        bar.localScale = scale;
    }

    public void ResetProgress() { shown = 0f; SetBar(0f); }
    public void Highlight(bool value) { if (highlight != null) highlight.gameObject.SetActive(value); }

    public void OnDrop(PointerEventData eventData)
    {
        var card = eventData.pointerDrag != null
            ? eventData.pointerDrag.GetComponent<ComboCrewWorkerCard>() : null;
        if (owner == null) return;
        if (card != null && card.OwnsPointer(eventData))
        {
            if (owner.AssignWorker(card.WorkerIndex, index)) card.AcceptCurrentDrop();
            return;
        }
        var worker = eventData.pointerDrag != null
            ? eventData.pointerDrag.GetComponent<ComboCrewWorkerStationDrag>() : null;
        if (worker != null && worker.OwnsPointer(eventData)
            && owner.AssignWorker(worker.WorkerIndex, index)) worker.AcceptCurrentDrop();
    }

}
