using TMPro;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class RushBalanceController : MonoBehaviour
{
    [SerializeField] private MinigameSessionController session;
    [SerializeField] private RushCustomerView[] customers;
    [Tooltip("Uma bandeja reutilizável por mesa; mesma ordem de Customers.")]
    [SerializeField] private RushOrderView[] orderViews;
    [SerializeField] private RectTransform[] queueAnchors;
    [SerializeField] private RushQueueSlot[] queueTargets;
    [Tooltip("Quatro posições no balcão, uma por mesa.")]
    [SerializeField] private RectTransform[] counterAnchors;
    [SerializeField] private TMP_Text feedback;
    [Header("Balanceamento inicial")]
    [SerializeField, Min(.1f)] private float arrivalInterval = 2f;
    [SerializeField, Min(1f)] private float minimumPatience = 18f;
    [SerializeField, Min(1f)] private float maximumPatience = 28f;
    [Tooltip("Segundos para pedidos de um, dois e três itens.")]
    [SerializeField] private Vector3 preparationTimes = new Vector3(4f, 7f, 10f);
    [SerializeField, Range(0f, 1f)] private float secondarySpeed = .5f;
    private RushRound round;
    private int nextArrival, turn;
    private float arrivalClock, feedbackClock;
    private bool configured;

    private void Awake()
    {
        configured = ValidateSetup();
        if (session != null) session.RegisterGameplay(configured);
        if (!configured) { enabled = false; return; }
        round = new RushRound(session.MaximumOrders);
        round.Resolved += Resolved;
        for (int i = 0; i < customers.Length; i++)
        {
            customers[i].Initialize(this, i);
            orderViews[i].gameObject.SetActive(false);
            queueTargets[i].Highlight(false);
        }
    }

    private void OnEnable()
    {
        if (!configured) return;
        session.TurnPreparing += Prepare;
        session.TurnStarted += Begin;
    }
    private void OnDisable()
    {
        if (session == null) return;
        session.TurnPreparing -= Prepare;
        session.TurnStarted -= Begin;
    }

    private void Prepare(int index, int count)
    {
        turn = index;
        nextArrival = 0;
        round.Reset(count);
        feedback.text = string.Empty;
        feedbackClock = 0f;
        for (int i = 0; i < customers.Length; i++)
        {
            customers[i].Clear();
            orderViews[i].gameObject.SetActive(false);
            queueTargets[i].Highlight(false);
        }
    }
    private void Begin(int index, int count) { arrivalClock = 0f; }

    private void Update()
    {
        if (!configured || !session.IsPlaying) return;
        float delta = Time.deltaTime;
        round.Tick(delta, secondarySpeed);
        if (!session.IsPlaying) return;
        arrivalClock -= delta;
        if (arrivalClock <= 0f && nextArrival < round.Count)
        {
            for (int table = 0; table < customers.Length; table++)
            {
                if (!customers[table].Available) continue;
                int id = nextArrival++;
                int items = Random.Range(1, 4);
                float duration = items == 1 ? preparationTimes.x : items == 2 ? preparationTimes.y : preparationTimes.z;
                round.Arrive(id, table, items, Random.Range(minimumPatience, maximumPatience), duration);
                customers[table].Arrive(id, round.Orders[id]);
                orderViews[table].Bind(this, id, items, table);
                arrivalClock = arrivalInterval;
                break;
            }
        }
        Refresh();
        if (feedbackClock > 0f && (feedbackClock -= delta) <= 0f) feedback.text = string.Empty;
    }

    public void Queue(int id)
    {
        if (!session.IsPlaying || !round.Enqueue(id)) return;
        AudioManager.Instance?.PlayConfirm();
        MequiHaptics.Selection();
        Refresh();
    }
    public void Reorder(int id, int rank)
    {
        if (!session.IsPlaying || !round.Move(id, rank)) return;
        AudioManager.Instance?.PlayConfirm();
        MequiHaptics.Selection();
        Refresh();
    }
    public void ReorderOnto(int id, int targetId)
    {
        if (!session.IsPlaying || round == null) return;
        Reorder(id, round.Rank(targetId));
    }
    public void Deliver(int id, int table)
    {
        if (!session.IsPlaying) return;
        if (!round.Deliver(id, table))
        {
            Message("Confira a mesa. O pedido precisa estar pronto.");
            MequiHaptics.Reject();
        }
    }
    public bool CanDrag(int id)
    {
        if (!session.IsPlaying || round == null || id < 0 || id >= round.Count) return false;
        // Um arraste por vez evita que dois dedos disputem a mesma fila.
        foreach (RushOrderView view in orderViews)
            if (view.IsDragging && view.OrderId != id) return false;
        return round.Orders[id].State == RushRound.Status.Queued || round.Orders[id].State == RushRound.Status.Ready;
    }

    public RectTransform Anchor(int id)
    {
        if (round == null || id < 0 || id >= round.Count) return null;
        RushRound.Order order = round.Orders[id];
        int rank = round.Rank(id);
        return order.State == RushRound.Status.Ready ? counterAnchors[order.Table]
            : rank >= 0 ? queueAnchors[rank] : null;
    }

    public void Highlight(int id, bool value)
    {
        if (!configured || round == null) return;
        bool queued = id >= 0 && id < round.Count && round.Orders[id].State == RushRound.Status.Queued;
        for (int i = 0; i < customers.Length; i++)
        {
            queueTargets[i].Highlight(value && queued && i < round.QueueCount);
            customers[i].Highlight(value && !queued && customers[i].OrderId == id);
        }
    }
    private void Refresh()
    {
        for (int i = 0; i < customers.Length; i++)
        {
            int id = customers[i].OrderId;
            if (id < 0) continue;
            customers[i].Refresh(round.Orders[id]);
            orderViews[i].Refresh(round.Orders[id]);
        }
        foreach (RushOrderView view in orderViews)
            if (view.IsDragging) Highlight(view.OrderId, true);
    }
    private void Resolved(int id, bool delivered)
    {
        int table = round.Orders[id].Table;
        orderViews[table].gameObject.SetActive(false);
        customers[table].Depart();
        Message(delivered ? "Pedido entregue!" : "O cliente foi embora.");
        if (delivered)
        {
            AudioManager.Instance?.PlayConfirm();
            MequiHaptics.Confirm();
        }
        session.TryResolveOrder(turn, id, delivered);
    }
    private void Message(string text) { feedback.text = text; feedbackClock = 1.6f; }

    private bool SetupError(string detail)
    {
        Debug.LogError($"Rush Balance — {name}: {detail}", this);
        return false;
    }

    private bool ValidateSetup()
    {
        if (session == null) return SetupError("session não atribuído.");
        if (session.MaximumOrders < 1) return SetupError("session.ordersPerTurn precisa conter três inteiros positivos (4, 5, 6).");
        if (feedback == null) return SetupError("feedback não atribuído.");
        if (customers == null || customers.Length != 4) return SetupError("customers precisa de quatro elementos.");
        if (orderViews == null || orderViews.Length != 4) return SetupError("orderViews precisa de quatro elementos.");
        if (queueAnchors == null || queueAnchors.Length != 4) return SetupError("queueAnchors precisa de quatro elementos.");
        if (queueTargets == null || queueTargets.Length != 4) return SetupError("queueTargets precisa de quatro elementos.");
        if (counterAnchors == null || counterAnchors.Length != 4) return SetupError("counterAnchors precisa de quatro elementos.");
        if (arrivalInterval <= 0f || minimumPatience <= 0f || maximumPatience < minimumPatience
            || preparationTimes.x <= 0f || preparationTimes.y <= 0f || preparationTimes.z <= 0f
            || secondarySpeed < 0f || secondarySpeed > 1f)
            return SetupError("Tempos de chegada, paciência ou preparo inválidos.");
        for (int i = 0; i < 4; i++)
        {
            if (customers[i] == null) return SetupError($"customers[{i}] não atribuído.");
            if (orderViews[i] == null) return SetupError($"orderViews[{i}] não atribuído.");
            if (queueAnchors[i] == null) return SetupError($"queueAnchors[{i}] não atribuído.");
            if (queueTargets[i] == null) return SetupError($"queueTargets[{i}] não atribuído.");
            if (counterAnchors[i] == null) return SetupError($"counterAnchors[{i}] não atribuído.");
            if (!customers[i].Configured) return SetupError($"customers[{i}] ({customers[i].name}): {customers[i].ConfigurationError} não configurado.");
            if (!orderViews[i].Configured) return SetupError($"orderViews[{i}] ({orderViews[i].name}): {orderViews[i].ConfigurationError} não configurado.");
            if (!queueTargets[i].ConfiguredFor(this, i))
                return SetupError($"queueTargets[{i}] ({queueTargets[i].name}): confira controller, rank = {i} e highlight.");
            for (int j = 0; j < i; j++)
                if (customers[i] == customers[j] || orderViews[i] == orderViews[j]
                    || queueAnchors[i] == queueAnchors[j] || counterAnchors[i] == counterAnchors[j]
                    || queueTargets[i] == queueTargets[j])
                    return SetupError($"Referência repetida entre os slots {j} e {i}.");
        }
        return true;
    }
}
