using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class RushCustomerView : MonoBehaviour, IDropHandler
{
    [SerializeField] private RectTransform character;
    [SerializeField] private RectTransform entrance;
    [SerializeField] private RectTransform seat;
    [SerializeField] private RectTransform exit;
    [SerializeField] private GameObject balloon;
    [SerializeField] private Button orderButton;
    [SerializeField] private Image patienceFill;
    [SerializeField] private TMP_Text speech;
    [Tooltip("Três ícones já configurados com arte pelo Inspector.")]
    [SerializeField] private GameObject[] itemIcons;
    [Tooltip("Ordem: feliz, sério, zangado. Objetos com as artes prontas.")]
    [SerializeField] private GameObject[] faces;
    [SerializeField] private GameObject dropHighlight;
    [SerializeField, Min(.01f)] private float movementSeconds = .3f;
    [SerializeField] private string happyMessage = "Posso esperar um pouco.";
    [SerializeField] private string seriousMessage = "Vai demorar muito?";
    [SerializeField] private string angryMessage = "Estou com pressa!";
    private RushBalanceController owner;
    private Tween movement;
    private int table;
    private int mood = -1;
    private bool departing;
    public int OrderId { get; private set; } = -1;
    public bool Available => OrderId < 0 && !departing;
    // Retorna o campo ausente para o diagnóstico de configuração.
    public string ConfigurationError =>
        character == null ? "character" :
        entrance == null ? "entrance" :
        seat == null ? "seat" :
        exit == null ? "exit" :
        balloon == null ? "balloon" :
        orderButton == null ? "orderButton" :
        patienceFill == null ? "patienceFill" :
        speech == null ? "speech" :
        dropHighlight == null ? "dropHighlight" :
        itemIcons == null || itemIcons.Length != 3 ? "itemIcons: esperado 3 elementos" :
        itemIcons[0] == null ? "itemIcons[0]" :
        itemIcons[1] == null ? "itemIcons[1]" :
        itemIcons[2] == null ? "itemIcons[2]" :
        faces == null || faces.Length != 3 ? "faces: esperado 3 elementos" :
        faces[0] == null ? "faces[0]" :
        faces[1] == null ? "faces[1]" :
        faces[2] == null ? "faces[2]" :
        null;
    public bool Configured => ConfigurationError == null;

    public void Initialize(RushBalanceController controller, int tableIndex)
    {
        owner = controller;
        table = tableIndex;
        orderButton.onClick.AddListener(SelectOrder);
        Clear();
    }

    public void Clear()
    {
        movement?.Kill();
        OrderId = -1;
        departing = false;
        character.gameObject.SetActive(false);
        balloon.SetActive(false);
        patienceFill.gameObject.SetActive(false);
        Highlight(false);
    }

    public void Arrive(int id, RushRound.Order order)
    {
        movement?.Kill();
        OrderId = id;
        mood = -1;
        character.gameObject.SetActive(true);
        character.position = entrance.position;
        movement = character.DOMove(seat.position, movementSeconds).SetEase(Ease.OutCubic);
        balloon.SetActive(true);
        patienceFill.gameObject.SetActive(true);
        for (int i = 0; i < itemIcons.Length; i++) itemIcons[i].SetActive(i < order.Items);
        Refresh(order);
    }

    public void Refresh(RushRound.Order order)
    {
        float ratio = Mathf.Clamp01(order.Remaining / order.Patience);
        patienceFill.fillAmount = ratio;
        int nextMood = ratio > .65f ? 0 : ratio > .3f ? 1 : 2;
        if (mood != nextMood)
        {
            mood = nextMood;
            for (int i = 0; i < faces.Length; i++) faces[i].SetActive(i == mood);
            string message = mood == 0 ? happyMessage : mood == 1 ? seriousMessage : angryMessage;
            speech.text = $"Mesa {table + 1} · {message}";
        }
        bool waiting = order.State == RushRound.Status.Waiting;
        orderButton.interactable = waiting;
        for (int i = 0; i < itemIcons.Length; i++)
            itemIcons[i].SetActive(i < order.Items);
    }

    public void Depart()
    {
        OrderId = -1;
        departing = true;
        balloon.SetActive(false);
        patienceFill.gameObject.SetActive(false);
        Highlight(false);
        movement?.Kill();
        movement = character.DOMove(exit.position, movementSeconds).SetEase(Ease.InCubic)
            .OnComplete(() => { character.gameObject.SetActive(false); departing = false; });
    }

    private void SelectOrder() { if (owner != null) owner.Queue(OrderId); }
    public void Highlight(bool value) { if (dropHighlight != null) dropHighlight.SetActive(value); }
    public void OnDrop(PointerEventData data)
    {
        if (owner == null || data.pointerDrag == null) return;
        RushOrderView order = data.pointerDrag.GetComponent<RushOrderView>();
        if (order != null && order.Owner == owner && order.OwnsPointer(data)) owner.Deliver(order.OrderId, table);
    }
    private void OnDisable() { movement?.Kill(); }
    private void OnDestroy() { if (orderButton != null) orderButton.onClick.RemoveListener(SelectOrder); }
}
