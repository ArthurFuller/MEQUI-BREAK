using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public sealed class RushOrderView : HierarchyDragHandle, IDropHandler
{
    [SerializeField] private GameObject[] itemIcons;
    [SerializeField] private Image progressFill;
    [SerializeField] private GameObject readyHighlight;
    [SerializeField] private TMP_Text tableLabel;

    private RectTransform previousAnchor;
    private Tween readyPulse;
    private Vector3 readyBaseScale;
    private bool visualDefaultsCached;
    private bool wasReady;

    public RushBalanceController Owner { get; private set; }
    public int OrderId { get; private set; } = -1;
    public string ConfigurationError =>
        DragConfigurationError != null ? DragConfigurationError :
        progressFill == null ? "progressFill" :
        readyHighlight == null ? "readyHighlight" :
        tableLabel == null ? "tableLabel" :
        itemIcons == null || itemIcons.Length != 3 ? "itemIcons: esperado 3 elementos" :
        itemIcons[0] == null ? "itemIcons[0]" :
        itemIcons[1] == null ? "itemIcons[1]" :
        itemIcons[2] == null ? "itemIcons[2]" :
        null;
    public bool Configured => ConfigurationError == null;
    protected override bool CanDrag => Owner != null && Owner.CanDrag(OrderId);
    protected override Vector3 RestPosition => Owner != null && Owner.Anchor(OrderId) != null
        ? Owner.Anchor(OrderId).position : transform.position;

    protected override void Awake()
    {
        base.Awake();
        CacheVisualDefaults();
    }

    private void CacheVisualDefaults()
    {
        if (visualDefaultsCached || readyHighlight == null) return;
        ConfigureHorizontalFill(progressFill);
        readyBaseScale = readyHighlight.transform.localScale;
        visualDefaultsCached = true;
    }

    private static void ConfigureHorizontalFill(Image image)
    {
        if (image == null) return;
        image.type = Image.Type.Filled;
        image.fillMethod = Image.FillMethod.Horizontal;
        image.fillOrigin = (int)Image.OriginHorizontal.Left;
        image.fillClockwise = true;
    }

    public void Bind(RushBalanceController controller, int id, int items, int table)
    {
        CacheVisualDefaults();
        Owner = controller;
        OrderId = id;
        previousAnchor = null;
        wasReady = false;
        readyPulse?.Kill();
        if (readyHighlight != null && visualDefaultsCached) readyHighlight.transform.localScale = readyBaseScale;
        tableLabel.SetText("Mesa {0}", table + 1);
        for (int i = 0; i < itemIcons.Length; i++) itemIcons[i].SetActive(i < items);
        gameObject.SetActive(false);
    }

    public void Refresh(RushRound.Order order)
    {
        bool visible = order.State == RushRound.Status.Queued || order.State == RushRound.Status.Ready;
        if (!visible)
        {
            readyPulse?.Kill();
            if (readyHighlight != null) readyHighlight.transform.localScale = readyBaseScale;
            gameObject.SetActive(false);
            return;
        }

        bool wasVisible = gameObject.activeSelf;
        gameObject.SetActive(true);
        progressFill.fillAmount = Mathf.Clamp01(order.Work / order.Duration);
        bool ready = order.State == RushRound.Status.Ready;
        readyHighlight.SetActive(ready);

        if (ready && !wasReady)
        {
            AudioManager.Instance?.PlayReady();
            readyPulse?.Kill();
            readyHighlight.transform.localScale = readyBaseScale;
            readyPulse = readyHighlight.transform
                .DOPunchScale(Vector3.one * .06f, .2f, 2, .3f)
                .OnComplete(() => readyHighlight.transform.localScale = readyBaseScale);
        }
        wasReady = ready;

        RectTransform anchor = Owner.Anchor(OrderId);
        if (anchor != previousAnchor || !wasVisible)
        {
            previousAnchor = anchor;
            if (ready && IsDragging) CancelDrag(false);
            else MoveHome(!wasVisible);
        }
    }

    protected override void HighlightTargets(bool value)
    {
        if (Owner != null) Owner.Highlight(OrderId, value);
    }

    public void OnDrop(PointerEventData data)
    {
        if (Owner == null || data.pointerDrag == null) return;
        RushOrderView dragged = data.pointerDrag.GetComponent<RushOrderView>();
        if (dragged != null && dragged != this && dragged.Owner == Owner && dragged.OwnsPointer(data))
            Owner.ReorderOnto(dragged.OrderId, OrderId);
    }

    protected override void OnDisable()
    {
        base.OnDisable();
        readyPulse?.Kill();
        if (readyHighlight != null && visualDefaultsCached) readyHighlight.transform.localScale = readyBaseScale;
    }
}
