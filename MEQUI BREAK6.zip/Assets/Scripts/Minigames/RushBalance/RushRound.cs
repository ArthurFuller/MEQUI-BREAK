using System;

/// <summary>Fila e preparo sem dependência de cenas ou assets.</summary>
public sealed class RushRound
{
    public enum Status { Hidden, Waiting, Queued, Ready, Delivered, Missed }
    public struct Order
    {
        public Status State;
        public int Table, Items;
        public float Remaining, Patience, Work, Duration;
    }

    public readonly Order[] Orders;
    private readonly int[] queue;
    public int Count { get; private set; }
    public int QueueCount { get; private set; }
    public event Action<int, bool> Resolved;

    public RushRound(int capacity)
    {
        Orders = new Order[capacity];
        queue = new int[capacity];
    }

    public void Reset(int count)
    {
        if (count < 1 || count > Orders.Length) throw new ArgumentOutOfRangeException(nameof(count));
        Array.Clear(Orders, 0, Orders.Length);
        Count = count;
        QueueCount = 0;
    }

    public void Arrive(int id, int table, int items, float patience, float duration)
    {
        if (id < 0 || id >= Count || Orders[id].State != Status.Hidden) return;
        Orders[id] = new Order { State = Status.Waiting, Table = table, Items = items,
            Patience = Math.Max(.1f, patience), Remaining = Math.Max(.1f, patience),
            Duration = Math.Max(.1f, duration) };
    }

    public bool Enqueue(int id)
    {
        if (id < 0 || id >= Count || Orders[id].State != Status.Waiting) return false;
        Orders[id].State = Status.Queued;
        queue[QueueCount++] = id;
        return true;
    }

    public int Rank(int id)
    {
        for (int i = 0; i < QueueCount; i++) if (queue[i] == id) return i;
        return -1;
    }

    public bool Move(int id, int rank)
    {
        int previous = Rank(id);
        if (previous < 0 || rank < 0 || rank >= QueueCount || previous == rank) return false;
        for (int i = previous; i < rank; i++) queue[i] = queue[i + 1];
        for (int i = previous; i > rank; i--) queue[i] = queue[i - 1];
        queue[rank] = id;
        return true;
    }

    public void Tick(float seconds, float secondaryRate)
    {
        if (seconds <= 0f) return;
        for (int i = 0; i < Count; i++)
        {
            Status state = Orders[i].State;
            if (state != Status.Waiting && state != Status.Queued && state != Status.Ready) continue;
            Orders[i].Remaining = Math.Max(0f, Orders[i].Remaining - seconds);
            if (Orders[i].Remaining <= 0f) Resolve(i, false);
        }

        // Captura os dois índices antes de alterar a fila: ninguém recebe dois avanços no mesmo frame.
        int first = QueueCount > 0 ? queue[0] : -1;
        int second = QueueCount > 1 ? queue[1] : -1;
        Advance(first, seconds);
        Advance(second, seconds * Math.Max(0f, Math.Min(1f, secondaryRate)));
    }

    private void Advance(int id, float seconds)
    {
        if (id < 0) return;
        Orders[id].Work = Math.Min(Orders[id].Duration, Orders[id].Work + seconds);
        if (Orders[id].Work < Orders[id].Duration) return;
        Orders[id].State = Status.Ready;
        RemoveFromQueue(id);
    }

    public bool Deliver(int id, int table)
    {
        if (id < 0 || id >= Count || Orders[id].State != Status.Ready
            || Orders[id].Table != table) return false;
        Resolve(id, true);
        return true;
    }

    private void Resolve(int id, bool delivered)
    {
        RemoveFromQueue(id);
        Orders[id].State = delivered ? Status.Delivered : Status.Missed;
        Resolved?.Invoke(id, delivered);
    }

    private void RemoveFromQueue(int id)
    {
        int rank = Rank(id);
        if (rank < 0) return;
        for (int i = rank; i < QueueCount - 1; i++) queue[i] = queue[i + 1];
        QueueCount--;
    }
}
