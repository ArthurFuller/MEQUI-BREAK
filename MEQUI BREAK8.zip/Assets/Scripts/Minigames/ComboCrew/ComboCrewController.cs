using System.Collections.Generic;
using DG.Tweening;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public sealed class ComboCrewController : MonoBehaviour
{
    private enum OrderStatus { Hidden, Cooking, DeliveredWaitingWash, Completed, Missed }
    private enum TrayStatus { Clean, InUse, Dirty, Washing }
    private sealed class RuntimeOrder
    {
        public OrderStatus Status;
        public int Tray = -1;
        public int View = -1;
        public float Deadline;
        public float Remaining;
    }

    [Header("Sessão e equipe")]
    [SerializeField] private MinigameSessionController session;
    [SerializeField] private CrewClipboardController clipboard;
    [SerializeField] private CrewMember[] crewMembers;
    [Tooltip("Preparo, chapa, montagem, entrega e louça.")]
    [SerializeField] private KitchenStation[] stations;

    [Header("Pedidos — objetos da Hierarchy")]
    [SerializeField] private ComboOrderView[] orderViews;
    [SerializeField] private RectTransform[] orderItems;
    [SerializeField] private RectTransform hiddenItemAnchor;
    [SerializeField] private RectTransform deliveryPickupAnchor;

    [Header("Bandejas — objetos da Hierarchy")]
    [SerializeField] private RectTransform[] trays;
    [SerializeField] private RectTransform[] cleanTrayAnchors;
    [SerializeField] private RectTransform[] dirtyTrayAnchors;
    [SerializeField] private RectTransform dirtyPickupAnchor;
    [SerializeField] private Image collectionProgressFill;
    [SerializeField] private DirtyTrayDropZone dirtyTrayDropZone;
    [SerializeField] private TMP_Text cleanTrayLabel;
    [SerializeField] private TMP_Text feedback;

    [Header("Balanceamento")]
    [SerializeField, Min(.1f)] private float spawnInterval = 1.4f;
    [SerializeField] private Vector3 deadlinesByTurn = new Vector3(34f, 31f, 28f);
    [SerializeField, Min(.05f)] private float workerTravelSeconds = .32f;
    [SerializeField, Min(.05f)] private float itemTravelSeconds = .25f;
    [SerializeField, Min(0f)] private float deliveryPickupDelay = .5f;
    [Tooltip("Coleta para 1, 2, 3 e 4 bandejas.")]
    [SerializeField] private Vector4 collectionSeconds = new Vector4(.75f, 1.25f, 1.75f, 2.25f);
    [SerializeField, Min(.1f)] private float washBaseSeconds = .7f;
    [SerializeField, Min(.1f)] private float washSecondsPerTray = .55f;

    private RuntimeOrder[] orders;
    private TrayStatus[] trayStates;
    private int[] trayOrders;
    private Tween[] trayTweens;
    private Tween[] itemTweens;
    private readonly Sequence[] stationTransfers = new Sequence[4];
    private Sequence washSequence;
    private CrewMember pendingWashMember;
    private int turn, targetOrders, nextOrder;
    private float spawnClock, feedbackClock, nextNoTrayFeedbackTime;
    private bool configured, washing;

    public CrewMember[] CrewMembers => crewMembers;
    public KitchenStation[] Stations => stations;

    private void Awake()
    {
        configured = ValidateSetup();
        if (session != null) session.RegisterGameplay(configured);
        if (!configured) { enabled = false; return; }
        orders = new RuntimeOrder[session.MaximumOrders];
        for (int i = 0; i < orders.Length; i++) orders[i] = new RuntimeOrder();
        trayStates = new TrayStatus[trays.Length];
        trayOrders = new int[trays.Length];
        trayTweens = new Tween[trays.Length];
        itemTweens = new Tween[orderItems.Length];
        foreach (KitchenStation station in stations) station.Initialize(this);
        foreach (ComboOrderView view in orderViews) view.Initialize();
        for (int i = 0; i < crewMembers.Length; i++) crewMembers[i].Initialize(this, i);
        for (int i = 0; i < crewMembers.Length; i++)
        {
            KitchenStation start = crewMembers[i].StartStation;
            if (start != null && start.AssignedCrew == null) AssignCrewInternal(crewMembers[i], start, true, false);
        }
        ResetVisuals(true);
        feedback.text = string.Empty;
        dirtyTrayDropZone.SetHighlighted(false);
    }

    private void OnEnable()
    {
        if (!configured) return;
        session.TurnPreparing += Prepare;
        session.TurnStarted += Begin;
    }

    private void OnDisable()
    {
        if (session != null) { session.TurnPreparing -= Prepare; session.TurnStarted -= Begin; }
        KillMotion();
    }

    private void Prepare(int index, int count)
    {
        KillMotion();
        turn = index; targetOrders = count; nextOrder = 0;
        spawnClock = feedbackClock = nextNoTrayFeedbackTime = 0f;
        feedback.text = "Abra a equipe e distribua as pessoas antes do turno.";
        foreach (KitchenStation station in stations) { station.ClearWork(); station.ForceRepair(); station.SetAuxiliaryProgress(0f); }
        foreach (RuntimeOrder order in orders)
        {
            order.Status = OrderStatus.Hidden; order.Tray = order.View = -1; order.Deadline = order.Remaining = 0f;
        }
        foreach (ComboOrderView view in orderViews) view.Hide(true);
        foreach (CrewMember member in crewMembers) if (member.IsAbsent) member.SetAbsent(false);
        ResetVisuals(false);
        clipboard.Open();
    }

    private void Begin(int index, int count)
    {
        spawnClock = 0f;
        clipboard.Close();
        ShowFeedback("Turno iniciado. Evite gargalos e recupere as bandejas.");
    }

    private void Update()
    {
        if (!configured || !session.IsPlaying) return;
        float delta = Time.deltaTime;
        TickOrders(delta);
        if (!session.IsPlaying) return;
        for (int i = 0; i < 4; i++) if (stations[i].Tick(delta)) TryAdvance(i);
        spawnClock -= delta;
        if (nextOrder < targetOrders && spawnClock <= 0f)
        {
            if (TrySpawnOrder()) spawnClock = spawnInterval;
            else spawnClock = .25f;
        }
        if (feedbackClock > 0f && (feedbackClock -= delta) <= 0f) feedback.text = string.Empty;
    }

    public bool CanArrangeCrew(CrewMember member) => configured && member != null && !member.IsAbsent && session.CanArrange;

    public void HandleCrewDragState(CrewMember member, bool dragging)
    {
        if (dragging) clipboard.Close();
        else if (member != null && member.Station == null && session.CanArrange) clipboard.Open();
        bool washCandidate = dragging && DirtyTrayCount() > 0 && member != null && member.Station != null
            && member.Station.Type == KitchenStation.StationType.Wash && !washing;
        dirtyTrayDropZone.SetHighlighted(washCandidate);
    }

    public void HandleCrewDragFinished(CrewMember member, bool accepted)
    {
        dirtyTrayDropZone.SetHighlighted(false);
        if (member != pendingWashMember) return;
        pendingWashMember = null;
        BeginDirtyTrayCycle(member);
    }

    public bool RequestDirtyTrayCollection(CrewMember member)
    {
        if (!session.IsPlaying || washing || member == null || member.IsAbsent || DirtyTrayCount() == 0
            || member.Station == null || member.Station.Type != KitchenStation.StationType.Wash)
        {
            ShowFeedback("A pessoa da louça precisa buscar as bandejas sujas.");
            return false;
        }
        pendingWashMember = member;
        return true;
    }

    public void AssignCrew(CrewMember member, KitchenStation target)
    {
        if (!CanArrangeCrew(member) || target == null) return;
        if (washing && (target.Type == KitchenStation.StationType.Wash
            || (member.Station != null && member.Station.Type == KitchenStation.StationType.Wash)))
        {
            ShowFeedback("A pessoa da louça está concluindo o ciclo.");
            return;
        }
        AssignCrewInternal(member, target, false, true);
    }

    private void AssignCrewInternal(CrewMember member, KitchenStation target, bool instant, bool record)
    {
        KitchenStation source = member.Station;
        if (source == target) { member.SetStationFromController(target, instant); return; }
        CrewMember occupant = target.AssignedCrew;
        if (source != null) source.AssignCrew(null);
        if (occupant != null && occupant != member)
        {
            target.AssignCrew(null);
            if (source != null) { source.AssignCrew(occupant); occupant.SetStationFromController(source, instant); }
            else occupant.SetStationFromController(null, instant);
        }
        target.AssignCrew(member);
        member.SetStationFromController(target, instant);
        if (!record) return;
        EventLogger.Instance?.RecordUserAction($"crew_{member.MemberIndex}_{target.Type.ToString().ToLowerInvariant()}");
        AudioManager.Instance?.PlayConfirm();
        MequiHaptics.Selection();
        if (target.Busy) ShowFeedback($"{target.ShortName}: trabalho retomado.", 1.2f);
        else if (member.WorkMultiplier(target.Type) > 1f) ShowFeedback($"Especialidade ativa em {target.ShortName}.", 1.2f);
    }

    public void HighlightStations(CrewMember member, bool value)
    {
        if (!configured) return;
        foreach (KitchenStation station in stations)
            station.Highlight(value && member != null && !member.IsAbsent && station != member.Station);
    }

    public void RemoveCrewForAbsence(CrewMember member)
    {
        if (member == null) return;
        KitchenStation station = member.Station;
        if (station != null && station.AssignedCrew == member) station.AssignCrew(null);
        member.SetStationFromController(null, false);
    }

    public void RestoreCrewAfterAbsence(CrewMember member, KitchenStation preferred)
    {
        if (member == null) return;
        if (preferred != null && preferred.AssignedCrew == null) AssignCrewInternal(member, preferred, false, false);
        else member.SetStationFromController(null, false);
    }

    public void StationRepaired(KitchenStation station)
    {
        ShowFeedback($"{station.ShortName}: equipamento reparado.");
        EventLogger.Instance?.RecordActivityEvent($"incident_repaired_{station.Type.ToString().ToLowerInvariant()}");
        AudioManager.Instance?.PlayConfirm();
        MequiHaptics.Confirm();
    }

    public void ShowFeedback(string message, float seconds = 1.8f)
    {
        if (feedback == null) return;
        feedback.text = message;
        feedbackClock = Mathf.Max(.1f, seconds);
    }

    private bool TrySpawnOrder()
    {
        KitchenStation prep = stations[0];
        int view = FindFreeView();
        if (prep.Busy || view < 0) return false;
        int id = nextOrder++;
        RuntimeOrder order = orders[id];
        order.Status = OrderStatus.Cooking;
        order.View = view;
        order.Deadline = order.Remaining = DeadlineForTurn(turn);
        orderViews[view].Bind(id, order.Deadline);
        prep.TryLoad(id, -1);
        ShowItem(id, prep.TrayAnchor);
        AudioManager.Instance?.PlayConfirm();
        return true;
    }

    private void TickOrders(float delta)
    {
        for (int id = 0; id < targetOrders; id++)
        {
            RuntimeOrder order = orders[id];
            if (order.Status == OrderStatus.Cooking)
            {
                order.Remaining = Mathf.Max(0f, order.Remaining - delta);
                int stationIndex = FindStationIndex(id);
                string state = stationIndex >= 0 ? stations[stationIndex].ShortName : "EM TRÂNSITO";
                float progress = stationIndex >= 0 ? stations[stationIndex].Progress : 0f;
                if (order.View >= 0) orderViews[order.View].Refresh(order.Remaining, order.Deadline, state, progress);
                if (order.Remaining <= 0f) ExpireOrder(id);
            }
            else if (order.Status == OrderStatus.DeliveredWaitingWash && order.View >= 0)
                orderViews[order.View].RefreshStage("LOUÇA", 0f);
        }
    }

    private void TryAdvance(int stationIndex)
    {
        if (stationTransfers[stationIndex] != null && stationTransfers[stationIndex].IsActive()) return;
        KitchenStation source = stations[stationIndex];
        int id = source.OrderId;
        if (id < 0 || id >= targetOrders || source.AssignedCrew == null) return;
        if (stationIndex == 3) { BeginDelivery(source, id); return; }
        KitchenStation next = stations[stationIndex + 1];
        if (next.Busy) return;
        RuntimeOrder order = orders[id];
        if (next.Type == KitchenStation.StationType.Assembly && order.Tray < 0)
        {
            int tray = FindCleanTray();
            if (tray < 0)
            {
                if (Time.unscaledTime >= nextNoTrayFeedbackTime)
                {
                    nextNoTrayFeedbackTime = Time.unscaledTime + 1.5f;
                    ShowFeedback("Sem bandeja limpa. Arraste a pessoa da louça até as bandejas sujas.");
                }
                return;
            }
            order.Tray = tray;
            trayStates[tray] = TrayStatus.InUse;
            trayOrders[tray] = id;
            MoveTray(tray, next.TrayAnchor, false);
            RefreshTrayLabel();
        }
        CrewMember worker = source.AssignedCrew;
        worker.SetTransporting(true);
        Vector3 home = source.CrewAnchor.position;
        stationTransfers[stationIndex] = DOTween.Sequence()
            .Append(worker.DragVisual.DOMove(next.CrewAnchor.position, workerTravelSeconds).SetEase(Ease.InOutCubic))
            .Join(orderItems[id].DOMove(next.TrayAnchor.position, itemTravelSeconds).SetEase(Ease.InOutCubic))
            .AppendCallback(() => { source.ClearWork(); next.TryLoad(id, order.Tray); AudioManager.Instance?.PlayConfirm(); })
            .Append(worker.DragVisual.DOMove(home, workerTravelSeconds).SetEase(Ease.OutCubic))
            .OnComplete(() => { worker.SetTransporting(false); stationTransfers[stationIndex] = null; });
    }

    private void BeginDelivery(KitchenStation source, int id)
    {
        RuntimeOrder order = orders[id];
        CrewMember worker = source.AssignedCrew;
        worker.SetTransporting(true);
        Vector3 home = source.CrewAnchor.position;
        stationTransfers[3] = DOTween.Sequence()
            .Append(worker.DragVisual.DOMove(deliveryPickupAnchor.position, workerTravelSeconds).SetEase(Ease.InOutCubic))
            .Join(orderItems[id].DOMove(deliveryPickupAnchor.position, itemTravelSeconds).SetEase(Ease.InOutCubic))
            .AppendInterval(deliveryPickupDelay)
            .AppendCallback(() =>
            {
                source.ClearWork();
                order.Status = OrderStatus.DeliveredWaitingWash;
                orderItems[id].gameObject.SetActive(false);
                if (order.View >= 0) orderViews[order.View].MarkDelivered();
                if (order.Tray >= 0)
                {
                    trayStates[order.Tray] = TrayStatus.Dirty;
                    MoveTray(order.Tray, dirtyTrayAnchors[DirtyTrayCount() - 1], false);
                }
                ShowFeedback("Pedido entregue. A bandeja está aguardando a louça.");
                AudioManager.Instance?.PlayReady();
            })
            .Append(worker.DragVisual.DOMove(home, workerTravelSeconds).SetEase(Ease.OutCubic))
            .OnComplete(() => { worker.SetTransporting(false); stationTransfers[3] = null; });
    }

    private void BeginDirtyTrayCycle(CrewMember worker)
    {
        List<int> batch = new List<int>();
        for (int i = 0; i < trayStates.Length; i++) if (trayStates[i] == TrayStatus.Dirty) batch.Add(i);
        if (batch.Count == 0) return;
        washing = true;
        worker.SetTransporting(true);
        KitchenStation wash = stations[4];
        float collectSeconds = CollectionDuration(batch.Count);
        float washSeconds = (washBaseSeconds + washSecondsPerTray * batch.Count) / worker.WorkMultiplier(wash.Type);
        Vector3 washHome = wash.CrewAnchor.position;
        SetFill(collectionProgressFill, 0f);
        washSequence = DOTween.Sequence()
            .Append(worker.DragVisual.DOMove(dirtyPickupAnchor.position, workerTravelSeconds).SetEase(Ease.InOutCubic))
            .Append(DOTween.To(() => 0f, v => SetFill(collectionProgressFill, v), 1f, collectSeconds).SetEase(Ease.Linear))
            .AppendCallback(() =>
            {
                foreach (int tray in batch) { trayStates[tray] = TrayStatus.Washing; MoveTray(tray, worker.CarryAnchor, false); }
            })
            .Append(worker.DragVisual.DOMove(washHome, workerTravelSeconds).SetEase(Ease.OutCubic))
            .Append(DOTween.To(() => 0f, wash.SetAuxiliaryProgress, 1f, washSeconds).SetEase(Ease.Linear))
            .Append(worker.DragVisual.DOMove(stations[2].TrayAnchor.position, workerTravelSeconds).SetEase(Ease.InOutCubic))
            .AppendCallback(() =>
            {
                foreach (int tray in batch)
                {
                    int orderId = trayOrders[tray];
                    trayStates[tray] = TrayStatus.Clean;
                    trayOrders[tray] = -1;
                    MoveTray(tray, cleanTrayAnchors[tray], false);
                    CompleteDeliveredOrder(orderId);
                }
                RefreshTrayLabel();
                wash.SetAuxiliaryProgress(0f);
                SetFill(collectionProgressFill, 0f);
            })
            .Append(worker.DragVisual.DOMove(washHome, workerTravelSeconds).SetEase(Ease.OutCubic))
            .OnComplete(() =>
            {
                washing = false;
                worker.SetTransporting(false);
                washSequence = null;
                ShowFeedback("Bandejas limpas devolvidas à montagem.");
                AudioManager.Instance?.PlayConfirm();
                MequiHaptics.Confirm();
            });
    }

    private void CompleteDeliveredOrder(int id)
    {
        if (id < 0 || id >= targetOrders || orders[id].Status != OrderStatus.DeliveredWaitingWash) return;
        RuntimeOrder order = orders[id];
        order.Status = OrderStatus.Completed;
        if (order.View >= 0) orderViews[order.View].Hide(false);
        session.TryResolveOrder(turn, id, true);
    }

    private void ExpireOrder(int id)
    {
        RuntimeOrder order = orders[id];
        if (order.Status != OrderStatus.Cooking) return;
        int stationIndex = FindStationIndex(id);
        if (stationIndex >= 0)
        {
            if (stationIndex < stationTransfers.Length && stationTransfers[stationIndex] != null)
            {
                stationTransfers[stationIndex].Kill();
                stationTransfers[stationIndex] = null;
                stations[stationIndex].AssignedCrew?.SetTransporting(false);
            }
            stations[stationIndex].ClearWork();
        }
        order.Status = OrderStatus.Missed;
        if (order.View >= 0) orderViews[order.View].MarkExpired();
        orderItems[id].gameObject.SetActive(false);
        if (order.Tray >= 0) ReleaseTray(order.Tray);
        ShowFeedback("O pedido expirou e saiu da linha.");
        AudioManager.Instance?.PlayError();
        MequiHaptics.Reject();
        session.TryResolveOrder(turn, id, false);
    }

    private int FindStationIndex(int orderId)
    {
        for (int i = 0; i < 4; i++) if (stations[i].Busy && stations[i].OrderId == orderId) return i;
        return -1;
    }

    private int FindFreeView()
    {
        for (int i = 0; i < orderViews.Length; i++) if (orderViews[i].Available) return i;
        return -1;
    }

    private int FindCleanTray()
    {
        for (int i = 0; i < trayStates.Length; i++) if (trayStates[i] == TrayStatus.Clean) return i;
        return -1;
    }

    private int DirtyTrayCount()
    {
        int count = 0;
        if (trayStates != null) foreach (TrayStatus value in trayStates) if (value == TrayStatus.Dirty) count++;
        return count;
    }

    private float DeadlineForTurn(int index) => Mathf.Max(1f, index <= 0 ? deadlinesByTurn.x : index == 1 ? deadlinesByTurn.y : deadlinesByTurn.z);
    private float CollectionDuration(int count) => count <= 1 ? collectionSeconds.x : count == 2 ? collectionSeconds.y : count == 3 ? collectionSeconds.z : collectionSeconds.w;

    private void ResetVisuals(bool instant)
    {
        washing = false;
        pendingWashMember = null;
        SetFill(collectionProgressFill, 0f);
        for (int i = 0; i < orderItems.Length; i++)
        {
            orderItems[i].gameObject.SetActive(false);
            orderItems[i].position = hiddenItemAnchor.position;
            orderItems[i].localScale = Vector3.one;
        }
        for (int i = 0; i < trays.Length; i++)
        {
            trayStates[i] = TrayStatus.Clean;
            trayOrders[i] = -1;
            MoveTray(i, cleanTrayAnchors[i], instant);
        }
        RefreshTrayLabel();
    }

    private void ShowItem(int id, RectTransform anchor)
    {
        if (id < 0 || id >= orderItems.Length) return;
        RectTransform item = orderItems[id];
        item.gameObject.SetActive(true);
        itemTweens[id]?.Kill();
        item.position = hiddenItemAnchor.position;
        item.localScale = Vector3.zero;
        itemTweens[id] = DOTween.Sequence()
            .Join(item.DOMove(anchor.position, itemTravelSeconds).SetEase(Ease.OutCubic))
            .Join(item.DOScale(Vector3.one, itemTravelSeconds).SetEase(Ease.OutBack));
    }

    private void ReleaseTray(int tray)
    {
        if (tray < 0 || tray >= trays.Length) return;
        trayStates[tray] = TrayStatus.Clean;
        trayOrders[tray] = -1;
        MoveTray(tray, cleanTrayAnchors[tray], false);
        RefreshTrayLabel();
    }

    private void MoveTray(int index, RectTransform anchor, bool instant)
    {
        if (index < 0 || index >= trays.Length || anchor == null) return;
        trayTweens[index]?.Kill();
        trays[index].gameObject.SetActive(true);
        if (instant) trays[index].position = anchor.position;
        else trayTweens[index] = trays[index].DOMove(anchor.position, itemTravelSeconds).SetEase(Ease.OutCubic);
    }

    private void RefreshTrayLabel()
    {
        int clean = 0;
        if (trayStates != null) foreach (TrayStatus value in trayStates) if (value == TrayStatus.Clean) clean++;
        cleanTrayLabel.SetText("Bandejas limpas: {0}/{1}", clean, trays.Length);
    }

    private static void SetFill(Image image, float value)
    {
        if (image == null) return;
        RectTransform rect = image.rectTransform;
        Vector2 max = rect.anchorMax;
        max.x = Mathf.Clamp01(value);
        rect.anchorMax = max;
        rect.anchoredPosition = Vector2.zero;
        rect.sizeDelta = Vector2.zero;
    }

    private void KillMotion()
    {
        foreach (Sequence sequence in stationTransfers) sequence?.Kill();
        washSequence?.Kill();
        if (trayTweens != null) foreach (Tween tween in trayTweens) tween?.Kill();
        if (itemTweens != null) foreach (Tween tween in itemTweens) tween?.Kill();
    }

    private bool SetupError(string detail) { Debug.LogError($"Combo Crew — {name}: {detail}", this); return false; }

    private bool ValidateSetup()
    {
        if (session == null) return SetupError("session não atribuído.");
        if (clipboard == null || !clipboard.Configured) return SetupError("clipboard não configurado.");
        if (crewMembers == null || crewMembers.Length != 4) return SetupError("crewMembers precisa de quatro elementos.");
        if (stations == null || stations.Length != 5) return SetupError("stations precisa de preparo, chapa, montagem, entrega e louça.");
        if (orderViews == null || orderViews.Length != 4) return SetupError("orderViews precisa de quatro elementos.");
        if (orderItems == null || orderItems.Length < session.MaximumOrders) return SetupError("orderItems insuficiente para os pedidos do turno.");
        if (trays == null || trays.Length != 4 || cleanTrayAnchors == null || cleanTrayAnchors.Length != 4
            || dirtyTrayAnchors == null || dirtyTrayAnchors.Length != 4) return SetupError("bandejas e anchors precisam de quatro elementos.");
        if (hiddenItemAnchor == null) return SetupError("hiddenItemAnchor não atribuído.");
        if (deliveryPickupAnchor == null) return SetupError("deliveryPickupAnchor não atribuído.");
        if (dirtyPickupAnchor == null) return SetupError("dirtyPickupAnchor não atribuído.");
        if (collectionProgressFill == null) return SetupError("collectionProgressFill não atribuído.");
        if (dirtyTrayDropZone == null) return SetupError("dirtyTrayDropZone não atribuído.");
        if (!dirtyTrayDropZone.Configured) return SetupError("dirtyTrayDropZone possui referências internas incompletas.");
        if (cleanTrayLabel == null) return SetupError("cleanTrayLabel não atribuído.");
        if (feedback == null) return SetupError("feedback não atribuído.");
        KitchenStation.StationType[] expected = { KitchenStation.StationType.Preparation, KitchenStation.StationType.Grill,
            KitchenStation.StationType.Assembly, KitchenStation.StationType.Delivery, KitchenStation.StationType.Wash };
        for (int i = 0; i < stations.Length; i++)
            if (stations[i] == null || !stations[i].Configured || stations[i].Type != expected[i]) return SetupError($"stations[{i}] inválida.");
        for (int i = 0; i < crewMembers.Length; i++) if (crewMembers[i] == null || !crewMembers[i].Configured) return SetupError($"crewMembers[{i}] inválido.");
        for (int i = 0; i < orderViews.Length; i++) if (orderViews[i] == null || !orderViews[i].Configured) return SetupError($"orderViews[{i}] inválido.");
        return true;
    }
}
