using UnityEngine;
using UnityEngine.EventSystems;

[DisallowMultipleComponent]
public sealed class DirtyTrayDropZone : MonoBehaviour, IDropHandler
{
    [SerializeField] private ComboCrewController controller;
    [SerializeField] private GameObject highlight;

    public bool Configured => controller != null && highlight != null;
    public void SetHighlighted(bool value) { if (highlight != null) highlight.SetActive(value); }

    public void OnDrop(PointerEventData data)
    {
        if (controller == null || data.pointerDrag == null) return;
        CrewMember member = data.pointerDrag.GetComponent<CrewMember>();
        if (member != null && member.OwnsPointer(data) && controller.RequestDirtyTrayCollection(member))
            member.AcceptCurrentDrop();
    }
}
