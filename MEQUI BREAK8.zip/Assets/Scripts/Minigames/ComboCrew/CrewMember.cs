using TMPro;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class CrewMember : HierarchyDragHandle
{
    public enum Specialty
    {
        None,
        Preparation,
        Grill,
        Assembly,
        Delivery,
        Wash
    }

    [Header("Equipe — referências da cena")]
    [SerializeField] private RectTransform homeAnchor;
    [SerializeField] private RectTransform carryAnchor;
    [SerializeField] private KitchenStation startStation;
    [SerializeField] private GameObject absentOverlay;
    [SerializeField] private TMP_Text statusLabel;

    [Header("Equipe — balanceamento")]
    [SerializeField] private Specialty specialty;
    [SerializeField, Range(1f, 2f)] private float specialtyMultiplier = 1.25f;
    [SerializeField] private bool canBeAbsent = true;

    private ComboCrewController owner;
    private KitchenStation station;
    private KitchenStation stationBeforeAbsence;
    private int memberIndex;
    private bool absent;
    private bool transporting;

    public KitchenStation Station => station;
    public KitchenStation StartStation => startStation;
    public bool IsAbsent => absent;
    public bool CanBeAbsent => canBeAbsent && !transporting;
    public RectTransform CarryAnchor => carryAnchor;
    public int MemberIndex => memberIndex;
    public bool Configured => DragConfigured && homeAnchor != null && carryAnchor != null && absentOverlay != null && statusLabel != null;
    public string ConfigurationError => !DragConfigured ? DragConfigurationError
        : homeAnchor == null ? "homeAnchor"
        : carryAnchor == null ? "carryAnchor"
        : absentOverlay == null ? "absentOverlay"
        : statusLabel == null ? "statusLabel"
        : null;

    protected override bool CanDrag => !absent && !transporting && owner != null && owner.CanArrangeCrew(this);
    protected override Vector3 RestPosition => (station != null ? station.CrewAnchor : homeAnchor).position;

    public void Initialize(ComboCrewController controller, int index)
    {
        owner = controller;
        memberIndex = index;
        absent = false;
        station = null;
        stationBeforeAbsence = null;
        transporting = false;
        absentOverlay.SetActive(false);
        RefreshStatus();
        MoveHome(true);
    }

    public float WorkMultiplier(KitchenStation.StationType type)
    {
        if (absent) return 0f;
        return SpecialtyMatches(type) ? specialtyMultiplier : 1f;
    }

    public void SetStationFromController(KitchenStation value, bool instant = false)
    {
        station = value;
        RefreshStatus();
        MoveHome(instant);
    }

    public void SetAbsent(bool value)
    {
        if (!canBeAbsent || absent == value) return;

        absent = value;
        absentOverlay.SetActive(value);

        if (value)
        {
            stationBeforeAbsence = station;
            owner?.RemoveCrewForAbsence(this);
        }
        else
        {
            owner?.RestoreCrewAfterAbsence(this, stationBeforeAbsence);
            stationBeforeAbsence = null;
        }

        RefreshStatus();
        MoveHome(false);
    }

    protected override void HighlightTargets(bool visible)
    {
        owner?.HighlightStations(this, visible);
    }

    protected override void DragStateChanged(bool dragging)
    {
        owner?.HandleCrewDragState(this, dragging);
    }

    protected override void DragFinished(bool accepted)
    {
        owner?.HandleCrewDragFinished(this, accepted);
    }

    public void SetTransporting(bool value)
    {
        transporting = value;
        if (!value) MoveHome(false);
    }

    private void LateUpdate()
    {
        // O card fica numa camada de arraste independente, mas acompanha seu slot
        // enquanto a prancheta abre e fecha.
        if (!absent && !transporting && !IsDragging && station == null && homeAnchor != null && DragVisual != null)
            DragVisual.position = homeAnchor.position;
    }

    private bool SpecialtyMatches(KitchenStation.StationType type)
    {
        switch (specialty)
        {
            case Specialty.Preparation: return type == KitchenStation.StationType.Preparation;
            case Specialty.Grill: return type == KitchenStation.StationType.Grill;
            case Specialty.Assembly: return type == KitchenStation.StationType.Assembly;
            case Specialty.Delivery: return type == KitchenStation.StationType.Delivery;
            case Specialty.Wash: return type == KitchenStation.StationType.Wash;
            default: return false;
        }
    }

    private void RefreshStatus()
    {
        if (statusLabel == null) return;
        if (absent)
        {
            statusLabel.text = "AUSENTE";
            return;
        }

        statusLabel.text = station == null ? "DISPONÍVEL" : station.ShortName;
    }
}
