using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

[DisallowMultipleComponent]
public sealed class CrewClipboardController : MonoBehaviour
{
    [SerializeField] private RectTransform panel;
    [SerializeField] private RectTransform openedAnchor;
    [SerializeField] private RectTransform closedAnchor;
    [SerializeField] private Button toggleButton;
    [SerializeField, Min(.05f)] private float duration = .22f;

    private Tween movement;
    public bool IsOpen { get; private set; }
    public bool Configured => panel != null && openedAnchor != null && closedAnchor != null && toggleButton != null;

    private void Awake()
    {
        if (!Configured) { Debug.LogError($"{name}: prancheta não configurada.", this); enabled = false; return; }
        toggleButton.onClick.AddListener(Toggle);
        SetOpen(false, true);
    }

    public void Toggle() => SetOpen(!IsOpen, false);
    public void Open() => SetOpen(true, false);
    public void Close() => SetOpen(false, false);

    private void SetOpen(bool value, bool instant)
    {
        IsOpen = value;
        movement?.Kill();
        Vector3 target = (value ? openedAnchor : closedAnchor).position;
        if (instant) panel.position = target;
        else movement = panel.DOMove(target, duration).SetEase(Ease.OutCubic);
    }

    private void OnDestroy()
    {
        movement?.Kill();
        if (toggleButton != null) toggleButton.onClick.RemoveListener(Toggle);
    }
}
